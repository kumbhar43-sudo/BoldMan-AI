import { useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Heart, Loader2, Home, Receipt, Download, DollarSign } from 'lucide-react';
import { usePaymentSuccess, useGetCharitySettings } from '../hooks/useQueries';
import { toast } from 'sonner';

export default function PaymentSuccessPage() {
  const params = new URLSearchParams(window.location.search);
  const sessionId = params.get('sessionId') || '';
  const accountId = params.get('accountId') || '';
  const caffeineCustomerId = params.get('caffeineCustomerId') || '';

  const { data, isLoading, isError } = usePaymentSuccess(sessionId, accountId, caffeineCustomerId);
  const { data: charitySettings } = useGetCharitySettings();

  useEffect(() => {
    if (data) {
      console.log('Payment successful:', data);
    }
  }, [data]);

  const handleGoHome = () => {
    window.location.href = '/';
  };

  const handleDownloadInvoice = () => {
    toast.success('Invoice download will be available soon');
  };

  const calculateCharityAmount = (totalAmount: bigint) => {
    if (!charitySettings) return 0;
    return (Number(totalAmount) * Number(charitySettings.charityPercentage)) / 10000;
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-16 flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <Loader2 className="h-16 w-16 animate-spin text-purple-400 mx-auto mb-4" />
          <p className="text-white text-xl">Confirming payment and generating invoice...</p>
          <p className="text-purple-300 text-sm mt-2">Processing payment split and charity distribution</p>
        </div>
      </div>
    );
  }

  if (isError || !data) {
    return (
      <div className="container mx-auto px-4 py-16">
        <Card className="max-w-2xl mx-auto border-red-500/30 bg-red-950/20 backdrop-blur-lg">
          <CardHeader>
            <CardTitle className="text-2xl text-red-400">Payment Verification Failed</CardTitle>
            <CardDescription className="text-red-300">
              There was a problem verifying your payment
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-purple-200 mb-6">
              Please check your account or contact support.
            </p>
            <Button onClick={handleGoHome} className="bg-gradient-to-r from-purple-600 to-pink-600">
              <Home className="mr-2 h-4 w-4" />
              Go Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const charityAmount = calculateCharityAmount(data.payment.amount);
  const ownerAmount = (Number(data.payment.amount) / 100) - charityAmount;

  return (
    <div className="container mx-auto px-4 py-16">
      <Card className="max-w-3xl mx-auto border-green-500/30 bg-gradient-to-br from-green-950/20 to-purple-950/20 backdrop-blur-lg">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <CheckCircle className="h-20 w-20 text-green-400" />
          </div>
          <CardTitle className="text-3xl text-white mb-2">Payment Successful!</CardTitle>
          <CardDescription className="text-lg text-purple-200">
            Your subscription is now active
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="rounded-lg bg-white/5 p-6 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-purple-300">Total Amount:</span>
              <span className="text-white font-semibold text-xl">
                ${(Number(data.payment.amount) / 100).toFixed(2)} {data.payment.currency.toUpperCase()}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-purple-300">Payment Method:</span>
              <span className="text-white">
                {data.payment.paymentMethod.brand.toUpperCase()} •••• {data.payment.paymentMethod.last4}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-purple-300">Status:</span>
              <span className="text-green-400 font-semibold">{data.payment.status}</span>
            </div>
          </div>

          <div className="rounded-lg bg-gradient-to-r from-purple-600/20 to-pink-600/20 p-6 border border-purple-500/30 space-y-3">
            <div className="flex items-center gap-2 mb-3">
              <DollarSign className="h-5 w-5 text-purple-400" />
              <h3 className="text-white font-semibold">Payment Distribution</h3>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-purple-200">Owner Amount:</span>
                <span className="text-white font-semibold">${ownerAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-pink-300 flex items-center gap-1">
                  <Heart className="h-4 w-4 fill-pink-400" />
                  Charity Amount:
                </span>
                <span className="text-pink-400 font-semibold">${charityAmount.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="rounded-lg bg-gradient-to-r from-pink-600/20 to-purple-600/20 p-4 border border-pink-500/30">
            <div className="flex items-center gap-3">
              <Heart className="h-6 w-6 text-pink-400 fill-pink-400" />
              <div>
                <p className="text-white font-semibold">Thank you for your contribution!</p>
                <p className="text-sm text-purple-200">
                  ${charityAmount.toFixed(2)} has been automatically distributed to charity accounts
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-lg bg-white/5 p-4 border border-purple-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Receipt className="h-5 w-5 text-purple-400" />
              <h4 className="text-white font-semibold">Tax-Compliant Invoice</h4>
            </div>
            <p className="text-sm text-purple-300 mb-3">
              A detailed invoice with TDS and GST breakdown has been generated for your records
            </p>
            <Button
              onClick={handleDownloadInvoice}
              variant="outline"
              size="sm"
              className="w-full border-purple-500/30 text-white hover:bg-white/10"
            >
              <Download className="mr-2 h-4 w-4" />
              Download Invoice (PDF)
            </Button>
          </div>

          <div className="text-center space-y-4">
            <p className="text-purple-200">
              You can now use all premium features!
            </p>
            <Button
              onClick={handleGoHome}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <Home className="mr-2 h-5 w-5" />
              Go to Dashboard
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

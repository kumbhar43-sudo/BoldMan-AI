import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import VideoGallery from '../components/VideoGallery';
import StoryBuilder from '../components/StoryBuilder';
import ScriptEditor from '../components/ScriptEditor';
import VideoExplainerTab from '../components/VideoExplainerTab';
import AiAssistantToggle from '../components/AiAssistantToggle';
import FreemiumLimitsBanner from '../components/FreemiumLimitsBanner';
import RenderQueueStatus from '../components/RenderQueueStatus';
import SupportFAQ from '../components/SupportFAQ';
import SupportChatbot from '../components/SupportChatbot';
import DomainConfigGuide from '../components/DomainConfigGuide';
import AboutSection from '../components/AboutSection';
import { Card, CardContent } from '@/components/ui/card';
import { Video, BookOpen, FileText, MessageSquare, HelpCircle, Settings, Globe, Award, Info } from 'lucide-react';

export default function Dashboard() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white mb-2">Dashboard</h1>
        <p className="text-purple-200">Manage your videos, stories, and settings</p>
      </div>

      <FreemiumLimitsBanner />
      <RenderQueueStatus />

      <Tabs defaultValue="videos" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 lg:grid-cols-9 gap-2">
          <TabsTrigger value="videos" className="flex items-center gap-2">
            <Video className="h-4 w-4" />
            <span className="hidden sm:inline">Videos</span>
          </TabsTrigger>
          <TabsTrigger value="explainers" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            <span className="hidden sm:inline">Explainers</span>
          </TabsTrigger>
          <TabsTrigger value="stories" className="flex items-center gap-2">
            <BookOpen className="h-4 w-4" />
            <span className="hidden sm:inline">Stories</span>
          </TabsTrigger>
          <TabsTrigger value="scripts" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            <span className="hidden sm:inline">Scripts</span>
          </TabsTrigger>
          <TabsTrigger value="public" className="flex items-center gap-2">
            <Globe className="h-4 w-4" />
            <span className="hidden sm:inline">Public</span>
          </TabsTrigger>
          <TabsTrigger value="support" className="flex items-center gap-2">
            <HelpCircle className="h-4 w-4" />
            <span className="hidden sm:inline">Support</span>
          </TabsTrigger>
          <TabsTrigger value="domain" className="flex items-center gap-2">
            <Award className="h-4 w-4" />
            <span className="hidden sm:inline">Domain</span>
          </TabsTrigger>
          <TabsTrigger value="about" className="flex items-center gap-2">
            <Info className="h-4 w-4" />
            <span className="hidden sm:inline">About</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            <span className="hidden sm:inline">Settings</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="videos">
          <VideoGallery type="user" />
        </TabsContent>

        <TabsContent value="explainers">
          <VideoExplainerTab />
        </TabsContent>

        <TabsContent value="stories">
          <StoryBuilder />
        </TabsContent>

        <TabsContent value="scripts">
          <ScriptEditor />
        </TabsContent>

        <TabsContent value="public">
          <VideoGallery type="public" />
        </TabsContent>

        <TabsContent value="support">
          <div className="space-y-6">
            <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                  <HelpCircle className="h-6 w-6 text-purple-400" />
                  Support Center
                </h2>
                <p className="text-purple-200 mb-6">
                  Find answers to common questions or chat with our AI assistant
                </p>
                <div className="grid gap-6 lg:grid-cols-2">
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-3">Frequently Asked Questions</h3>
                    <SupportFAQ />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-3">AI Support Chatbot</h3>
                    <SupportChatbot />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="domain">
          <DomainConfigGuide />
        </TabsContent>

        <TabsContent value="about">
          <AboutSection />
        </TabsContent>

        <TabsContent value="settings">
          <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold text-white mb-4">Settings</h2>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-3">AI Prompt Assistant</h3>
                  <AiAssistantToggle />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

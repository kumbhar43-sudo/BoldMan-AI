import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { XCircle, Home, ArrowLeft } from 'lucide-react';

export default function PaymentCancelPage() {
  const handleGoHome = () => {
    window.location.href = '/';
  };

  const handleTryAgain = () => {
    window.location.href = '/?action=subscribe';
  };

  return (
    <div className="container mx-auto px-4 py-16">
      <Card className="max-w-2xl mx-auto border-yellow-500/30 bg-gradient-to-br from-yellow-950/20 to-purple-950/20 backdrop-blur-lg">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <XCircle className="h-20 w-20 text-yellow-400" />
          </div>
          <CardTitle className="text-3xl text-white mb-2">Payment Cancelled</CardTitle>
          <CardDescription className="text-lg text-purple-200">
            Your payment was not completed
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="rounded-lg bg-white/5 p-6 text-center">
            <p className="text-purple-200 mb-4">
              No worries! You have not been charged.
            </p>
            <p className="text-purple-300 text-sm">
              You can subscribe again at any time.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={handleTryAgain}
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <ArrowLeft className="mr-2 h-5 w-5" />
              Try Again
            </Button>
            <Button
              onClick={handleGoHome}
              size="lg"
              variant="outline"
              className="border-purple-500/30 bg-white/5 text-white hover:bg-white/10"
            >
              <Home className="mr-2 h-5 w-5" />
              Go Home
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

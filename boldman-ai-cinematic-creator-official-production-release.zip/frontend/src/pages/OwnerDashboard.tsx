import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Crown, 
  Heart, 
  DollarSign, 
  Users, 
  Settings, 
  TrendingUp,
  Shield,
  CreditCard,
  Receipt,
  AlertCircle
} from 'lucide-react';
import CharityManagementDialog from '../components/CharityManagementDialog';
import PaymentHistoryDialog from '../components/PaymentHistoryDialog';
import { useGetCharitySettings } from '../hooks/useQueries';
import { toast } from 'sonner';

export default function OwnerDashboard() {
  const [showCharityDialog, setShowCharityDialog] = useState(false);
  const [showPaymentHistory, setShowPaymentHistory] = useState(false);
  const { data: charitySettings } = useGetCharitySettings();

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <Crown className="h-8 w-8 text-yellow-400" />
          <h1 className="text-3xl font-bold text-white">Owner Dashboard</h1>
        </div>
        <p className="text-purple-200">Manage subscriptions, charity settings, and payment controls</p>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-4 mb-6">
        <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">$0.00</div>
            <p className="text-xs text-purple-300">No payments yet</p>
          </CardContent>
        </Card>

        <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Active Subscribers</CardTitle>
            <Users className="h-4 w-4 text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">0</div>
            <p className="text-xs text-purple-300">Across all plans</p>
          </CardContent>
        </Card>

        <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Charity Contributions</CardTitle>
            <Heart className="h-4 w-4 text-pink-400 fill-pink-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">
              {charitySettings ? `${charitySettings.charityPercentage}%` : '0%'}
            </div>
            <p className="text-xs text-purple-300">Of each payment</p>
          </CardContent>
        </Card>

        <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-white">Platform Status</CardTitle>
            <Shield className="h-4 w-4 text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-400">Active</div>
            <p className="text-xs text-purple-300">All systems operational</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="subscriptions" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 gap-2">
          <TabsTrigger value="subscriptions" className="flex items-center gap-2">
            <CreditCard className="h-4 w-4" />
            <span className="hidden sm:inline">Subscriptions</span>
          </TabsTrigger>
          <TabsTrigger value="charity" className="flex items-center gap-2">
            <Heart className="h-4 w-4" />
            <span className="hidden sm:inline">Charity</span>
          </TabsTrigger>
          <TabsTrigger value="payments" className="flex items-center gap-2">
            <Receipt className="h-4 w-4" />
            <span className="hidden sm:inline">Payments</span>
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            <span className="hidden sm:inline">Settings</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="subscriptions">
          <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <CreditCard className="h-5 w-5 text-purple-400" />
                Subscription Management
              </CardTitle>
              <CardDescription className="text-purple-300">
                Manage subscription plans and pricing
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="border-purple-500/20 bg-white/5">
                  <CardHeader>
                    <CardTitle className="text-sm text-white">Free Trial</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold text-white">$0.00</p>
                    <p className="text-xs text-purple-300">Limited features</p>
                  </CardContent>
                </Card>

                <Card className="border-purple-500/20 bg-white/5">
                  <CardHeader>
                    <CardTitle className="text-sm text-white">Basic Plan</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold text-white">$4.99</p>
                    <p className="text-xs text-purple-300">Standard features</p>
                  </CardContent>
                </Card>

                <Card className="border-purple-500/20 bg-white/5">
                  <CardHeader>
                    <CardTitle className="text-sm text-white">Pro Plan</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold text-white">$9.99</p>
                    <p className="text-xs text-purple-300">Advanced features</p>
                  </CardContent>
                </Card>

                <Card className="border-purple-500/20 bg-white/5">
                  <CardHeader>
                    <CardTitle className="text-sm text-white">Full Plan</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold text-white">$19.99</p>
                    <p className="text-xs text-purple-300">All features</p>
                  </CardContent>
                </Card>
              </div>

              <div className="flex items-center gap-2 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                <AlertCircle className="h-5 w-5 text-blue-400" />
                <p className="text-sm text-blue-200">
                  Subscription prices are configured in the backend. Contact support to modify pricing.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="charity">
          <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Heart className="h-5 w-5 text-pink-400 fill-pink-400" />
                Charity Configuration
              </CardTitle>
              <CardDescription className="text-purple-300">
                Configure charity accounts and payment distribution
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="text-white">Current Charity Percentage</Label>
                <div className="flex items-center gap-4">
                  <div className="text-3xl font-bold text-pink-400">
                    {charitySettings ? `${charitySettings.charityPercentage}%` : '0%'}
                  </div>
                  <p className="text-sm text-purple-300">
                    of each subscription payment goes to charity
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-white">Charity Fund Balance</Label>
                <div className="text-2xl font-bold text-white">
                  ${charitySettings ? Number(charitySettings.charityFundBalance) / 100 : 0}
                </div>
              </div>

              <Button
                onClick={() => setShowCharityDialog(true)}
                className="bg-gradient-to-r from-pink-600 to-rose-600 text-white hover:from-pink-700 hover:to-rose-700"
              >
                <Heart className="mr-2 h-4 w-4" />
                Manage Charity Accounts
              </Button>

              <div className="flex items-center gap-2 p-4 bg-pink-500/10 border border-pink-500/30 rounded-lg">
                <Heart className="h-5 w-5 text-pink-400" />
                <p className="text-sm text-pink-200">
                  Configure 4-5 charity accounts with individual percentage allocations. Total must equal 100%.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments">
          <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Receipt className="h-5 w-5 text-green-400" />
                Payment History & Transparency
              </CardTitle>
              <CardDescription className="text-purple-300">
                View all transactions, payment splits, and charity distributions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label className="text-white">Total Payments</Label>
                  <div className="text-2xl font-bold text-white">0</div>
                </div>

                <div className="space-y-2">
                  <Label className="text-white">Owner Revenue</Label>
                  <div className="text-2xl font-bold text-green-400">$0.00</div>
                </div>

                <div className="space-y-2">
                  <Label className="text-white">Charity Total</Label>
                  <div className="text-2xl font-bold text-pink-400">$0.00</div>
                </div>
              </div>

              <Button
                onClick={() => setShowPaymentHistory(true)}
                className="bg-gradient-to-r from-green-600 to-emerald-600 text-white hover:from-green-700 hover:to-emerald-700"
              >
                <Receipt className="mr-2 h-4 w-4" />
                View Payment History
              </Button>

              <div className="flex items-center gap-2 p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                <TrendingUp className="h-5 w-5 text-green-400" />
                <p className="text-sm text-green-200">
                  All payment splits and charity distributions are tracked transparently with tax-compliant invoices.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Settings className="h-5 w-5 text-purple-400" />
                Platform Settings
              </CardTitle>
              <CardDescription className="text-purple-300">
                Configure platform-wide settings and preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-white">Platform Name</Label>
                  <Input
                    value="BoldMan AI Cinematic Creator"
                    disabled
                    className="bg-white/5 border-purple-500/30 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-white">Custom Domain</Label>
                  <Input
                    value="boldman.ai"
                    disabled
                    className="bg-white/5 border-purple-500/30 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-white">Platform Status</Label>
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-green-400 animate-pulse"></div>
                    <span className="text-white">Active & Operational</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 p-4 bg-purple-500/10 border border-purple-500/30 rounded-lg">
                <Shield className="h-5 w-5 text-purple-400" />
                <p className="text-sm text-purple-200">
                  Platform is deployed on the Internet Computer network with full commercial rights.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {showCharityDialog && (
        <CharityManagementDialog
          open={showCharityDialog}
          onClose={() => setShowCharityDialog(false)}
        />
      )}

      {showPaymentHistory && (
        <PaymentHistoryDialog
          open={showPaymentHistory}
          onClose={() => setShowPaymentHistory(false)}
        />
      )}
    </div>
  );
}

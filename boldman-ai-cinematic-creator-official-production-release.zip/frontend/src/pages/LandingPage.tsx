import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Video, Wand2, Mic, Users, Download, Sparkles, Heart, CreditCard, Monitor, Globe, Smartphone, Shield, AlertTriangle, CheckCircle, Zap, Award, Rocket, Cloud, X } from 'lucide-react';
import { useInternetIdentity } from '../hooks/useInternetIdentity';

export default function LandingPage() {
  const { login } = useInternetIdentity();

  const features = [
    {
      icon: Monitor,
      title: '4K Cinematic Videos',
      description: 'Create videos in professional 4K quality',
    },
    {
      icon: Wand2,
      title: 'AI Scene Analysis',
      description: 'Automatic background music and visual settings',
    },
    {
      icon: Mic,
      title: 'Multi-Language Voice-Over',
      description: 'AI voices in multiple languages including Hindi',
    },
    {
      icon: Users,
      title: 'Multi-Character Stories',
      description: 'Create complex stories with multiple characters',
    },
    {
      icon: Video,
      title: '3D Animation',
      description: 'With lip-sync and camera movement',
    },
    {
      icon: Download,
      title: 'Easy Export',
      description: 'Share to YouTube and social media',
    },
  ];

  const platforms = [
    { icon: Globe, name: 'Web Browser', desc: 'All modern browsers' },
    { icon: Smartphone, name: 'Android & iOS', desc: 'As mobile app' },
    { icon: Monitor, name: 'Windows Desktop', desc: 'Desktop app' },
  ];

  const planComparison = [
    {
      name: 'Free Trial',
      prompts: '10/month',
      duration: '30 seconds',
      watermark: true,
      queue: 'Delayed',
      explainers: '2',
    },
    {
      name: 'Basic',
      prompts: '50/month',
      duration: '2 hours',
      watermark: false,
      queue: 'Standard',
      explainers: '10',
    },
    {
      name: 'Pro',
      prompts: '200/month',
      duration: '5 hours',
      watermark: false,
      queue: 'Priority',
      explainers: '50',
      popular: true,
    },
    {
      name: 'Full',
      prompts: 'Unlimited',
      duration: 'Unlimited',
      watermark: false,
      queue: 'Priority',
      explainers: 'Unlimited',
    },
  ];

  return (
    <div className="container mx-auto px-4 py-16">
      {/* Official Production Release Banner */}
      <div className="mb-12 text-center">
        <div className="inline-flex items-center gap-3 rounded-full bg-gradient-to-r from-green-600/20 to-emerald-600/20 border border-green-500/30 px-8 py-4 shadow-glow animate-pulse-glow">
          <Rocket className="h-7 w-7 text-green-400 animate-bounce" />
          <span className="text-xl font-bold text-green-100">
            🎉 OFFICIAL PRODUCTION RELEASE - NOW LIVE AT BOLDMAN.AI
          </span>
          <Zap className="h-7 w-7 text-yellow-400 animate-pulse" />
        </div>
        <p className="mt-4 text-sm text-purple-300 font-semibold">
          ✓ Custom Domain (boldman.ai) • ✓ Internet Computer Network • ✓ Full Commercial Rights • ✓ Cross-Platform PWA
        </p>
      </div>

      {/* Hero Section */}
      <div className="mb-20 text-center">
        <div className="mb-8 flex justify-center">
          <div className="relative">
            <img
              src="/assets/generated/video-camera-hero.dim_800x600.jpg"
              alt="Video Creation"
              className="rounded-2xl shadow-2xl shadow-purple-500/50 max-w-2xl w-full"
            />
            <div className="absolute -top-4 -right-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-full shadow-glow font-bold text-lg animate-pulse">
              4K Ready
            </div>
            <div className="absolute -bottom-4 -left-4 bg-gradient-to-r from-blue-600 to-cyan-600 text-white px-6 py-3 rounded-full shadow-glow font-bold text-sm flex items-center gap-2">
              <Globe className="h-4 w-4" />
              <span>boldman.ai</span>
            </div>
          </div>
        </div>
        <h1 className="mb-6 text-5xl font-bold text-white md:text-6xl lg:text-7xl">
          <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
            BoldMan
          </span>
          {' '}AI Cinematic Creator
        </h1>
        <p className="mb-4 text-2xl font-semibold text-purple-100 max-w-3xl mx-auto">
          Official Production Release at boldman.ai
        </p>
        <p className="mb-8 text-xl text-purple-200 max-w-3xl mx-auto">
          Create professional 4K videos from text, scripts, or images. With AI-powered scene analysis, multi-character stories, voice-over, and 3D animation. Now officially live at <strong className="text-blue-300">boldman.ai</strong> on the public Internet Computer blockchain with full commercial rights.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button
            onClick={login}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-lg px-8 py-6 shadow-glow hover:shadow-glow-lg transition-all"
          >
            <Video className="mr-2 h-5 w-5" />
            Get Started - Free Trial
          </Button>
          <div className="flex items-center gap-2 text-purple-200">
            <Award className="h-5 w-5 text-purple-400" />
            <span className="text-sm font-semibold">Full Commercial Rights</span>
          </div>
        </div>
        <p className="mt-6 text-sm text-purple-300 font-semibold">
          ✓ Custom Domain (boldman.ai) • ✓ Internet Computer • ✓ Decentralized & Secure • ✓ 4K Capable
        </p>
      </div>

      {/* Freemium Plan Comparison */}
      <div className="mb-20">
        <h2 className="mb-8 text-center text-4xl font-bold text-white">
          Choose Your Plan
        </h2>
        <p className="text-center text-purple-200 mb-12 max-w-2xl mx-auto">
          Start with our free trial or upgrade to unlock unlimited features and priority rendering
        </p>
        <div className="overflow-x-auto">
          <div className="grid gap-6 md:grid-cols-4 min-w-[800px]">
            {planComparison.map((plan, index) => (
              <Card
                key={index}
                className={`border-purple-500/30 bg-white/5 backdrop-blur-lg ${
                  plan.popular ? 'ring-2 ring-purple-500 scale-105' : ''
                }`}
              >
                <CardContent className="p-6">
                  {plan.popular && (
                    <div className="mb-3 text-center">
                      <span className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-3 py-1 rounded-full text-xs font-bold">
                        Most Popular
                      </span>
                    </div>
                  )}
                  <h3 className="text-xl font-bold text-white mb-4 text-center">{plan.name}</h3>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-purple-300">AI Prompts:</span>
                      <span className="text-white font-semibold">{plan.prompts}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-purple-300">Video Duration:</span>
                      <span className="text-white font-semibold">{plan.duration}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-purple-300">Watermark:</span>
                      {plan.watermark ? (
                        <X className="h-4 w-4 text-red-400" />
                      ) : (
                        <CheckCircle className="h-4 w-4 text-green-400" />
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-purple-300">Render Queue:</span>
                      <span className={`font-semibold ${
                        plan.queue === 'Priority' ? 'text-green-400' : 
                        plan.queue === 'Standard' ? 'text-blue-400' : 'text-amber-400'
                      }`}>
                        {plan.queue}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-purple-300">Explainers:</span>
                      <span className="text-white font-semibold">{plan.explainers}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        <div className="mt-8 text-center">
          <Button
            onClick={login}
            size="lg"
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            <Sparkles className="mr-2 h-5 w-5" />
            Start Free Trial Now
          </Button>
        </div>
      </div>

      {/* Official Release Status Card */}
      <div className="mb-20">
        <Card className="border-green-500/30 bg-gradient-to-r from-green-600/10 to-emerald-600/10 backdrop-blur-lg">
          <CardContent className="p-8">
            <div className="text-center">
              <div className="flex justify-center gap-3 mb-6 flex-wrap">
                <div className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white px-6 py-3 rounded-full font-bold text-sm shadow-glow flex items-center gap-2">
                  <Globe className="h-4 w-4" />
                  <span>boldman.ai</span>
                </div>
                <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-3 rounded-full font-bold text-sm shadow-glow flex items-center gap-2">
                  <Cloud className="h-4 w-4" />
                  <span>INTERNET COMPUTER</span>
                </div>
                <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-full font-bold text-sm shadow-glow">
                  4K CAPABLE
                </div>
              </div>
              <h2 className="text-3xl font-bold text-white mb-4">
                BoldMan - Official Production Release at boldman.ai
              </h2>
              <p className="text-lg text-green-100 max-w-3xl mx-auto mb-4">
                Complete production-ready deployment with custom domain configuration. Official launch at <strong className="text-blue-300">boldman.ai</strong> on the public Internet Computer network with decentralized hosting and full commercial ownership.
              </p>
              <div className="grid gap-4 md:grid-cols-3 max-w-4xl mx-auto mt-6">
                <div className="bg-white/5 rounded-lg p-4 border border-purple-500/30">
                  <Globe className="h-8 w-8 text-blue-400 mx-auto mb-2" />
                  <p className="text-sm text-white font-semibold">Custom Domain</p>
                  <p className="text-xs text-blue-300 mt-1">boldman.ai</p>
                </div>
                <div className="bg-white/5 rounded-lg p-4 border border-purple-500/30">
                  <Award className="h-8 w-8 text-purple-400 mx-auto mb-2" />
                  <p className="text-sm text-white font-semibold">Full Commercial Rights</p>
                  <p className="text-xs text-purple-300 mt-1">Complete Ownership</p>
                </div>
                <div className="bg-white/5 rounded-lg p-4 border border-purple-500/30">
                  <Cloud className="h-8 w-8 text-green-400 mx-auto mb-2" />
                  <p className="text-sm text-white font-semibold">Internet Computer</p>
                  <p className="text-xs text-green-300 mt-1">Decentralized Hosting</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Content Safety Section */}
      <div className="mb-20">
        <Card className="border-blue-500/30 bg-gradient-to-r from-blue-600/10 to-cyan-600/10 backdrop-blur-lg">
          <CardContent className="p-8">
            <div className="grid gap-8 md:grid-cols-2 items-center">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <Shield className="h-10 w-10 text-blue-400" />
                  <h2 className="text-3xl font-bold text-white">AI Content Safety</h2>
                </div>
                <p className="text-blue-100 text-lg mb-4">
                  Our advanced AI moderation system ensures content safety and legal compliance.
                </p>
                <p className="text-blue-200 mb-4">
                  All uploaded and generated content is automatically scanned for violations including child abuse, animal cruelty, violence, and illegal acts.
                </p>
                <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-4 mt-4">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-400 flex-shrink-0 mt-0.5" />
                    <p className="text-sm text-amber-100">
                      <strong>User Responsibility:</strong> You are solely responsible for all content you create. Violations will be automatically blocked and logged.
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex justify-center">
                <img 
                  src="/assets/generated/content-safety-icon-transparent.dim_64x64.png" 
                  alt="Content Safety"
                  className="h-48 w-48 opacity-80"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Platform Support Section */}
      <div className="mb-20">
        <h2 className="mb-8 text-center text-3xl font-bold text-white">
          Available on All Platforms
        </h2>
        <div className="grid gap-6 md:grid-cols-3 max-w-4xl mx-auto">
          {platforms.map((platform, index) => (
            <Card
              key={index}
              className="border-purple-500/30 bg-white/5 backdrop-blur-lg hover:bg-white/10 transition-all text-center"
            >
              <CardContent className="p-6">
                <platform.icon className="h-12 w-12 text-purple-400 mx-auto mb-3" />
                <h3 className="text-lg font-semibold text-white mb-1">
                  {platform.name}
                </h3>
                <p className="text-sm text-purple-300">{platform.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
        <p className="text-center text-purple-200 mt-6 font-semibold">
          Progressive Web App (PWA) - Install once, use everywhere
        </p>
      </div>

      {/* Features Grid */}
      <div className="mb-20">
        <h2 className="mb-12 text-center text-4xl font-bold text-white">
          Powerful Features
        </h2>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <Card
              key={index}
              className="border-purple-500/30 bg-white/5 backdrop-blur-lg hover:bg-white/10 transition-all hover:shadow-glow"
            >
              <CardContent className="p-6">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 shadow-glow">
                  <feature.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="mb-2 text-xl font-semibold text-white">
                  {feature.title}
                </h3>
                <p className="text-purple-200">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Subscription & Charity Section */}
      <div className="mb-20">
        <div className="rounded-2xl bg-gradient-to-r from-pink-600/20 to-purple-600/20 p-8 border border-pink-500/30 shadow-brand">
          <div className="grid gap-8 md:grid-cols-2 items-center">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Heart className="h-8 w-8 text-pink-400 fill-pink-400 animate-pulse" />
                <h2 className="text-3xl font-bold text-white">Charity Contribution</h2>
              </div>
              <p className="text-purple-200 text-lg mb-4">
                A portion of each subscription purchase automatically goes to the charity fund.
              </p>
              <p className="text-purple-300 mb-4">
                You not only create your videos, but also help society.
              </p>
              <div className="flex items-center gap-2 text-sm text-purple-400">
                <Sparkles className="h-4 w-4" />
                <span>Secure payment by Stripe</span>
              </div>
            </div>
            <div className="flex justify-center">
              <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg hover:shadow-glow transition-all">
                <CardContent className="p-6">
                  <CreditCard className="h-12 w-12 text-purple-400 mb-4 mx-auto" />
                  <h3 className="text-xl font-semibold text-white text-center mb-2">
                    Flexible Subscription Plans
                  </h3>
                  <p className="text-purple-200 text-center text-sm mb-4">
                    Choose a plan that fits your needs
                  </p>
                  <ul className="text-xs text-purple-300 space-y-1">
                    <li>✓ Free Trial, Basic, Pro & Full Plans</li>
                    <li>✓ 4K video rendering</li>
                    <li>✓ Multi-character stories</li>
                    <li>✓ Voice cloning features</li>
                    <li>✓ Priority rendering for subscribers</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="mb-20">
        <h2 className="mb-12 text-center text-4xl font-bold text-white">
          How It Works
        </h2>
        <div className="grid gap-8 md:grid-cols-3">
          <div className="text-center">
            <div className="mb-4 flex justify-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-2xl font-bold text-white shadow-glow">
                1
              </div>
            </div>
            <h3 className="mb-2 text-xl font-semibold text-white">
              Upload Text or Image
            </h3>
            <p className="text-purple-200">
              Write your script or upload an image
            </p>
          </div>
          <div className="text-center">
            <div className="mb-4 flex justify-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-2xl font-bold text-white shadow-glow">
                2
              </div>
            </div>
            <h3 className="mb-2 text-xl font-semibold text-white">
              AI Does the Work
            </h3>
            <p className="text-purple-200">
              AI adds scenes, music, and voice-over
            </p>
          </div>
          <div className="text-center">
            <div className="mb-4 flex justify-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-2xl font-bold text-white shadow-glow">
                3
              </div>
            </div>
            <h3 className="mb-2 text-xl font-semibold text-white">
              Download in 4K
            </h3>
            <p className="text-purple-200">
              Download your 4K video or share directly
            </p>
          </div>
        </div>
      </div>

      {/* Official Production Badge */}
      <div className="mb-20">
        <Card className="border-purple-500/30 bg-gradient-to-r from-purple-600/10 to-pink-600/10 backdrop-blur-lg">
          <CardContent className="p-8 text-center">
            <div className="flex justify-center gap-3 mb-4 flex-wrap">
              <div className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white px-6 py-2 rounded-full font-bold text-sm shadow-glow flex items-center gap-2">
                <Globe className="h-4 w-4" />
                <span>boldman.ai</span>
              </div>
              <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-6 py-2 rounded-full font-bold text-sm shadow-glow flex items-center gap-2">
                <Cloud className="h-4 w-4" />
                <span>INTERNET COMPUTER</span>
              </div>
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-2 rounded-full font-bold text-sm shadow-glow">
                4K CAPABLE
              </div>
            </div>
            <h3 className="text-2xl font-bold text-white mb-3">
              Full Commercial Rights & Ownership
            </h3>
            <p className="text-purple-200 max-w-2xl mx-auto mb-4">
              All content you create is yours. Full ownership and exclusive commercial rights. 
              Ready for commercial use and public deployment at <strong className="text-blue-300">boldman.ai</strong>. Official production release on the Internet Computer blockchain with live environment.
            </p>
            <p className="text-sm text-purple-300 font-semibold">
              BoldMan AI Cinematic Creator - Professional Edition v1.0.0
            </p>
            <p className="text-xs text-green-400 mt-2 font-semibold">
              ✓ Custom Domain (boldman.ai) • ✓ Internet Computer Network • ✓ Decentralized & Secure • ✓ Cross-Platform PWA
            </p>
          </CardContent>
        </Card>
      </div>

      {/* CTA Section */}
      <div className="rounded-2xl bg-gradient-to-r from-purple-600 to-pink-600 p-12 text-center shadow-brand">
        <h2 className="mb-4 text-4xl font-bold text-white">
          Start Creating Today
        </h2>
        <p className="mb-8 text-xl text-white/90">
          Join the BoldMan community at <strong>boldman.ai</strong> and create your first 4K AI video on the Internet Computer
        </p>
        <Button
          onClick={login}
          size="lg"
          variant="secondary"
          className="bg-white text-purple-600 hover:bg-white/90 text-lg px-8 py-6 shadow-xl hover:shadow-2xl transition-all"
        >
          <Sparkles className="mr-2 h-5 w-5" />
          Sign Up Now - Free Trial
        </Button>
        <p className="mt-4 text-sm text-white/80">
          No credit card required • Start instantly • Full commercial rights
        </p>
        <p className="mt-2 text-xs text-white/70 font-semibold">
          Official Production Release at boldman.ai - Ready for Public Use
        </p>
      </div>
    </div>
  );
}

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import { useInternetIdentity } from './useInternetIdentity';
import type { 
  UserProfile, 
  VideoProject, 
  VideoProjectId, 
  CharitySettings,
  CreatePaymentResponse,
  PaymentSuccessResponse,
  SubscriptionTier,
  Story
} from '../backend';
import { ExternalBlob } from '../backend';
import { Principal } from '@dfinity/principal';

export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useIsCallerAdmin() {
  const { actor, isFetching: actorFetching } = useActor();
  const { identity } = useInternetIdentity();

  return useQuery<boolean>({
    queryKey: ['isCallerAdmin', identity?.getPrincipal().toString()],
    queryFn: async () => {
      if (!actor) return false;
      return actor.isCallerAdmin();
    },
    enabled: !!actor && !actorFetching && !!identity,
    retry: false,
  });
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
    },
  });
}

export function useGetVideosByUser() {
  const { actor, isFetching: actorFetching } = useActor();
  const { identity } = useInternetIdentity();

  return useQuery<VideoProject[]>({
    queryKey: ['userVideos', identity?.getPrincipal().toString()],
    queryFn: async () => {
      if (!actor || !identity) return [];
      return actor.getVideosByUser(identity.getPrincipal());
    },
    enabled: !!actor && !actorFetching && !!identity,
  });
}

export function useGetAllPublicVideos() {
  return useQuery<VideoProject[]>({
    queryKey: ['publicVideos'],
    queryFn: async () => {
      // Mock data until backend implements this
      return [];
    },
  });
}

export function useCreateVideoProject() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (params: {
      title: string;
      description: string;
      videoFile: ExternalBlob;
      language: string;
      thumbnail?: File | null;
    }) => {
      if (!actor) throw new Error('Actor not available');
      // Estimate duration as 30 seconds for free users (default)
      const estimatedDuration = BigInt(30);
      
      // Note: thumbnail handling would be done here if backend supported it
      // For now, we just pass the video file
      return actor.createVideoProject(
        params.title,
        params.description,
        params.videoFile,
        params.language,
        estimatedDuration
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userVideos'] });
      queryClient.invalidateQueries({ queryKey: ['freemiumLimits'] });
    },
  });
}

// Script hooks
export function useCreateScript() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (params: any) => {
      // Mock implementation until backend is ready
      console.log('Creating script:', params);
      return BigInt(1);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userScripts'] });
    },
  });
}

// Story hooks
export function useGetAllStoriesByUser() {
  const { identity } = useInternetIdentity();

  return useQuery<Story[]>({
    queryKey: ['userStories', identity?.getPrincipal().toString()],
    queryFn: async () => {
      // Mock data until backend implements this
      return [] as Story[];
    },
    enabled: !!identity,
  });
}

export function useCreateMultiCharacterStory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (params: any) => {
      // Mock implementation until backend is ready
      console.log('Creating story:', params);
      return BigInt(1);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userStories'] });
      queryClient.invalidateQueries({ queryKey: ['userVideos'] });
    },
  });
}

export function useUpdateStory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (params: any) => {
      // Mock implementation until backend is ready
      console.log('Updating story:', params);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userStories'] });
    },
  });
}

export function useDeleteStory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (storyId: bigint) => {
      // Mock implementation until backend is ready
      console.log('Deleting story:', storyId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userStories'] });
    },
  });
}

// Stripe and Subscription Hooks
export function useListStripePrices() {
  return useQuery({
    queryKey: ['stripePrices'],
    queryFn: async () => {
      // Mock data until backend implements this
      return [
        {
          priceId: 'free_trial',
          name: 'Free Trial Plan',
          description: 'Limited features with watermarked outputs',
          unitAmount: BigInt(0),
        },
        {
          priceId: 'basic_subscription',
          name: 'Basic Plan',
          description: 'Standard video creation with basic features',
          unitAmount: BigInt(499),
        },
        {
          priceId: 'pro_subscription',
          name: 'Pro Plan',
          description: 'Advanced features including multi-character stories',
          unitAmount: BigInt(999),
        },
        {
          priceId: 'full_subscription',
          name: 'Full Plan',
          description: 'Complete access to all premium features',
          unitAmount: BigInt(1999),
        },
      ];
    },
  });
}

export function useCheckout() {
  const { actor } = useActor();

  return useMutation({
    mutationFn: async (subscriptionType: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.checkout(subscriptionType);
    },
  });
}

export function usePaymentSuccess(sessionId: string, accountId: string, caffeineCustomerId: string) {
  const { actor, isFetching } = useActor();

  return useQuery<PaymentSuccessResponse>({
    queryKey: ['paymentSuccess', sessionId],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.paymentSuccess(sessionId, accountId, caffeineCustomerId);
    },
    enabled: !!actor && !isFetching && !!sessionId && !!accountId && !!caffeineCustomerId,
    retry: false,
  });
}

export function useGetCharitySettings() {
  const { actor, isFetching: actorFetching } = useActor();

  return useQuery<CharitySettings>({
    queryKey: ['charitySettings'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCharitySettings();
    },
    enabled: !!actor && !actorFetching,
  });
}

// AI Prompt Assistant Hooks
export function useIsPromptAssistantEnabled() {
  return useQuery<boolean>({
    queryKey: ['promptAssistantEnabled'],
    queryFn: async () => {
      // Default to enabled
      return true;
    },
  });
}

export function useToggleAiPromptAssistant() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (enabled: boolean) => {
      // Mock implementation until backend is ready
      console.log('Toggling AI assistant:', enabled);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['promptAssistantEnabled'] });
    },
  });
}

export function useCallExternalGeminiAPI() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (prompt: string) => {
      if (!actor) throw new Error('Actor not available');
      return actor.callExternalGeminiAPI(prompt);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['freemiumLimits'] });
    },
  });
}

// Freemium System Hooks
export function useGetFreemiumLimits() {
  const { identity } = useInternetIdentity();

  return useQuery({
    queryKey: ['freemiumLimits', identity?.getPrincipal().toString()],
    queryFn: async () => {
      // Mock data until backend implements this
      return {
        currentPromptCount: BigInt(3),
        maxPrompts: BigInt(10),
        currentVideoDuration: BigInt(45),
        maxVideoDuration: BigInt(1800),
        currentExplainers: BigInt(1),
        maxExplainers: BigInt(2),
        lastReset: BigInt(Date.now() * 1000000),
        subscriptionTier: 'free' as const,
      };
    },
    enabled: !!identity,
  });
}

export function useGetRenderQueueStatus() {
  return useQuery({
    queryKey: ['renderQueueStatus'],
    queryFn: async () => {
      // Mock data until backend implements this
      return {
        tasksInQueue: BigInt(5),
        estimatedWaitTime: BigInt(120),
      };
    },
    refetchInterval: 10000,
  });
}

export function useUpdateSubscriptionTier() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (params: { user: string; tier: SubscriptionTier }) => {
      if (!actor) throw new Error('Actor not available');
      const principal = Principal.fromText(params.user);
      return actor.updateSubscriptionTier(principal, params.tier);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['freemiumLimits'] });
    },
  });
}

// Placeholder hooks for features not yet in backend
export function useGetAllExplainersByUser() {
  const { identity } = useInternetIdentity();

  return useQuery({
    queryKey: ['userExplainers', identity?.getPrincipal().toString()],
    queryFn: async () => {
      // Return empty array until backend implements this
      return [];
    },
    enabled: !!identity,
  });
}

export function useCreateVideoExplainer() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (params: any) => {
      // Mock implementation until backend is ready
      console.log('Creating explainer:', params);
      return BigInt(1);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userExplainers'] });
      queryClient.invalidateQueries({ queryKey: ['freemiumLimits'] });
    },
  });
}

export function useCreateVoiceProfile() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (params: any) => {
      // Mock implementation until backend is ready
      console.log('Creating voice profile:', params);
      return BigInt(1);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['userVoiceProfiles'] });
    },
  });
}

export function useGetAllPublicLanguages() {
  return useQuery<string[]>({
    queryKey: ['publicLanguages'],
    queryFn: async () => {
      // Mock data until backend implements this
      return ['English', 'Hindi', 'Spanish', 'French', 'German', 'Chinese', 'Japanese'];
    },
  });
}

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Heart, Plus, Trash2, Save, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

interface CharityAccount {
  name: string;
  percentage: number;
  accountDetails: string;
  linkedStripeAccountId: string;
  description: string;
  totalAmountDonated: number;
}

interface CharityManagementDialogProps {
  open: boolean;
  onClose: () => void;
}

export default function CharityManagementDialog({ open, onClose }: CharityManagementDialogProps) {
  const [charities, setCharities] = useState<CharityAccount[]>([
    {
      name: 'Charity A',
      percentage: 30,
      accountDetails: 'Account details for Charity A',
      linkedStripeAccountId: 'acct_charity_a',
      description: 'Supporting education initiatives',
      totalAmountDonated: 0,
    },
    {
      name: 'Charity B',
      percentage: 25,
      accountDetails: 'Account details for Charity B',
      linkedStripeAccountId: 'acct_charity_b',
      description: 'Healthcare for underprivileged',
      totalAmountDonated: 0,
    },
    {
      name: 'Charity C',
      percentage: 20,
      accountDetails: 'Account details for Charity C',
      linkedStripeAccountId: 'acct_charity_c',
      description: 'Environmental conservation',
      totalAmountDonated: 0,
    },
    {
      name: 'Charity D',
      percentage: 25,
      accountDetails: 'Account details for Charity D',
      linkedStripeAccountId: 'acct_charity_d',
      description: 'Animal welfare programs',
      totalAmountDonated: 0,
    },
  ]);

  const totalPercentage = charities.reduce((sum, charity) => sum + charity.percentage, 0);

  const handleAddCharity = () => {
    if (charities.length >= 5) {
      toast.error('Maximum 5 charity accounts allowed');
      return;
    }
    setCharities([
      ...charities,
      {
        name: '',
        percentage: 0,
        accountDetails: '',
        linkedStripeAccountId: '',
        description: '',
        totalAmountDonated: 0,
      },
    ]);
  };

  const handleRemoveCharity = (index: number) => {
    if (charities.length <= 1) {
      toast.error('At least one charity account is required');
      return;
    }
    setCharities(charities.filter((_, i) => i !== index));
  };

  const handleUpdateCharity = (index: number, field: keyof CharityAccount, value: string | number) => {
    const updated = [...charities];
    updated[index] = { ...updated[index], [field]: value };
    setCharities(updated);
  };

  const handleSave = () => {
    if (totalPercentage !== 100) {
      toast.error('Total charity percentage must equal 100%');
      return;
    }

    const hasEmptyFields = charities.some(
      (charity) => !charity.name || !charity.linkedStripeAccountId || charity.percentage <= 0
    );

    if (hasEmptyFields) {
      toast.error('Please fill in all required fields');
      return;
    }

    toast.success('Charity settings saved successfully');
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-purple-950 via-indigo-950 to-blue-950 border-purple-500/30">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-white flex items-center gap-2">
            <Heart className="h-6 w-6 text-pink-400 fill-pink-400" />
            Charity Account Management
          </DialogTitle>
          <DialogDescription className="text-purple-200">
            Configure charity accounts and payment distribution percentages
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="rounded-lg bg-white/5 p-4 border border-purple-500/30">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-white font-semibold">Total Allocation</p>
                <p className="text-sm text-purple-300">Must equal 100%</p>
              </div>
              <div className="flex items-center gap-2">
                <span
                  className={`text-3xl font-bold ${
                    totalPercentage === 100 ? 'text-green-400' : 'text-red-400'
                  }`}
                >
                  {totalPercentage}%
                </span>
                {totalPercentage !== 100 && (
                  <AlertCircle className="h-5 w-5 text-red-400" />
                )}
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {charities.map((charity, index) => (
              <Card key={index} className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg text-white">
                      Charity Account {index + 1}
                    </CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveCharity(index)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="grid gap-3 md:grid-cols-2">
                    <div>
                      <Label className="text-purple-200">Charity Name *</Label>
                      <Input
                        value={charity.name}
                        onChange={(e) => handleUpdateCharity(index, 'name', e.target.value)}
                        placeholder="Enter charity name"
                        className="bg-white/10 border-purple-500/30 text-white"
                      />
                    </div>
                    <div>
                      <Label className="text-purple-200">Percentage Allocation * (%)</Label>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        value={charity.percentage}
                        onChange={(e) =>
                          handleUpdateCharity(index, 'percentage', parseInt(e.target.value) || 0)
                        }
                        placeholder="0"
                        className="bg-white/10 border-purple-500/30 text-white"
                      />
                    </div>
                  </div>
                  <div>
                    <Label className="text-purple-200">Linked Stripe Account ID *</Label>
                    <Input
                      value={charity.linkedStripeAccountId}
                      onChange={(e) =>
                        handleUpdateCharity(index, 'linkedStripeAccountId', e.target.value)
                      }
                      placeholder="acct_xxxxxxxxxxxxx"
                      className="bg-white/10 border-purple-500/30 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-purple-200">Account Details</Label>
                    <Input
                      value={charity.accountDetails}
                      onChange={(e) => handleUpdateCharity(index, 'accountDetails', e.target.value)}
                      placeholder="Bank account or payment details"
                      className="bg-white/10 border-purple-500/30 text-white"
                    />
                  </div>
                  <div>
                    <Label className="text-purple-200">Description</Label>
                    <Input
                      value={charity.description}
                      onChange={(e) => handleUpdateCharity(index, 'description', e.target.value)}
                      placeholder="Brief description of charity mission"
                      className="bg-white/10 border-purple-500/30 text-white"
                    />
                  </div>
                  <div className="pt-2 border-t border-purple-500/20">
                    <p className="text-sm text-purple-300">
                      Total Donated: ${charity.totalAmountDonated.toFixed(2)}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {charities.length < 5 && (
            <Button
              onClick={handleAddCharity}
              variant="outline"
              className="w-full border-purple-500/30 bg-white/5 text-white hover:bg-white/10"
            >
              <Plus className="mr-2 h-4 w-4" />
              Add Charity Account
            </Button>
          )}

          <div className="flex gap-3 pt-4">
            <Button
              onClick={handleSave}
              disabled={totalPercentage !== 100}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <Save className="mr-2 h-4 w-4" />
              Save Changes
            </Button>
            <Button onClick={onClose} variant="outline" className="border-purple-500/30 text-white">
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

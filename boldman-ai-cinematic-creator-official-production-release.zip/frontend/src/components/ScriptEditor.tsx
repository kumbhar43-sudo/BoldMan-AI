import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { FileText, Plus, Save, Sparkles } from 'lucide-react';
import { useCreateScript, useIsPromptAssistantEnabled } from '../hooks/useQueries';
import { toast } from 'sonner';
import ContentResponsibilityModal from './ContentResponsibilityModal';
import AiPromptAssistant from './AiPromptAssistant';

export default function ScriptEditor() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [showEditor, setShowEditor] = useState(false);
  const [showResponsibilityModal, setShowResponsibilityModal] = useState(false);
  const [showAiAssistant, setShowAiAssistant] = useState(false);
  
  const createScript = useCreateScript();
  const { data: isAiEnabled } = useIsPromptAssistantEnabled();

  const handleSave = async () => {
    if (!title.trim() || !content.trim()) {
      toast.error('Please enter title and content');
      return;
    }

    try {
      await createScript.mutateAsync({
        title: title.trim(),
        content: content.trim(),
        language: 'en',
        characters: [],
      });
      toast.success('Script saved successfully!');
      setTitle('');
      setContent('');
      setShowEditor(false);
    } catch (error: any) {
      if (error?.message?.includes('violates safety guidelines')) {
        toast.error('Content blocked: Violates safety guidelines', {
          description: 'Your content was flagged by our AI safety system. Please review our content policy.',
          duration: 5000,
        });
      } else {
        toast.error('Error saving script');
      }
      console.error(error);
    }
  };

  const handleSaveWithAcknowledgment = () => {
    setShowResponsibilityModal(true);
  };

  const handleResponsibilityAccept = () => {
    setShowResponsibilityModal(false);
    handleSave();
  };

  const handleAiSuggestionApply = (suggestion: string) => {
    setContent(prev => prev ? `${prev}\n\n${suggestion}` : suggestion);
  };

  if (!showEditor) {
    return (
      <div className="text-center py-16">
        <div className="mb-4 flex justify-center">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-white/10">
            <FileText className="h-10 w-10 text-purple-300" />
          </div>
        </div>
        <h3 className="text-2xl font-semibold text-white mb-2">
          Create Your Scripts
        </h3>
        <p className="text-purple-200 mb-6">
          Write and save scripts for your videos
        </p>
        <Button
          onClick={() => setShowEditor(true)}
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          <Plus className="mr-2 h-5 w-5" />
          Create New Script
        </Button>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-6">
        <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2">
                <FileText className="h-5 w-5" />
                New Script
              </CardTitle>
              {isAiEnabled && (
                <Button
                  onClick={() => setShowAiAssistant(!showAiAssistant)}
                  variant="outline"
                  size="sm"
                  className="border-purple-500/30 bg-white/10 text-white hover:bg-white/20"
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  {showAiAssistant ? 'Hide' : 'Show'} AI Assistant
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="script-title" className="text-white">Title</Label>
              <Input
                id="script-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Script title"
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="script-content" className="text-white">Content</Label>
              <Textarea
                id="script-content"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Write your script here..."
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50 min-h-96 font-mono"
              />
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleSaveWithAcknowledgment}
                disabled={createScript.isPending}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                <Save className="mr-2 h-4 w-4" />
                {createScript.isPending ? 'Saving...' : 'Save Script'}
              </Button>
              <Button
                onClick={() => {
                  setShowEditor(false);
                  setTitle('');
                  setContent('');
                }}
                variant="outline"
                className="border-white/20 bg-white/10 text-white hover:bg-white/20"
              >
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>

        {isAiEnabled && showAiAssistant && (
          <AiPromptAssistant
            context={`Title: ${title}\n\nContent: ${content}`}
            onSuggestionApply={handleAiSuggestionApply}
            placeholder="Ask AI to help with your script..."
            mode="script"
          />
        )}
      </div>

      <ContentResponsibilityModal
        open={showResponsibilityModal}
        onAccept={handleResponsibilityAccept}
        onCancel={() => setShowResponsibilityModal(false)}
      />
    </>
  );
}

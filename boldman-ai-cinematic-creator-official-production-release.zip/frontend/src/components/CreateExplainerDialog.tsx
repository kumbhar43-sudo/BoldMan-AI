import { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Mic, Upload, Loader2, Volume2, Sparkles } from 'lucide-react';
import { useCreateVideoExplainer, useGetVideosByUser, useGetAllPublicLanguages, useCreateVoiceProfile, useIsPromptAssistantEnabled } from '../hooks/useQueries';
import { ExternalBlob } from '../backend';
import { toast } from 'sonner';
import ContentResponsibilityModal from './ContentResponsibilityModal';
import AiPromptAssistant from './AiPromptAssistant';

interface CreateExplainerDialogProps {
  onClose: () => void;
  preselectedVideoId?: bigint | null;
}

export default function CreateExplainerDialog({ onClose, preselectedVideoId }: CreateExplainerDialogProps) {
  const [selectedVideoId, setSelectedVideoId] = useState<string>(preselectedVideoId?.toString() || '');
  const [language, setLanguage] = useState('English');
  const [voiceType, setVoiceType] = useState('female');
  const [tone, setTone] = useState('professional');
  const [accent, setAccent] = useState('American');
  const [content, setContent] = useState('');
  const [voiceOption, setVoiceOption] = useState<'ai' | 'clone'>('ai');
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [voiceProfileName, setVoiceProfileName] = useState('');
  const [showResponsibilityModal, setShowResponsibilityModal] = useState(false);
  const [showAiAssistant, setShowAiAssistant] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: videos } = useGetVideosByUser();
  const { data: languages } = useGetAllPublicLanguages();
  const createExplainer = useCreateVideoExplainer();
  const createVoiceProfile = useCreateVoiceProfile();
  const { data: isAiEnabled } = useIsPromptAssistantEnabled();

  const handleSubmit = async () => {
    if (!selectedVideoId) {
      toast.error('Please select a video');
      return;
    }

    if (!content.trim()) {
      toast.error('Please enter explanation content');
      return;
    }

    try {
      let voiceProfile = null;

      if (voiceOption === 'clone' && audioBlob) {
        const audioArray = new Uint8Array(await audioBlob.arrayBuffer());
        const externalBlob = ExternalBlob.fromBytes(audioArray);
        
        await createVoiceProfile.mutateAsync({
          name: voiceProfileName || 'My Voice',
          voiceStyle: voiceType,
          language,
          accent,
          tones: tone,
          sampleAudio: externalBlob,
        });
      }

      await createExplainer.mutateAsync({
        videoId: BigInt(selectedVideoId),
        language,
        voice: voiceType,
        tone,
        accent,
        voiceType,
        content,
        voiceProfile,
      });

      toast.success('Video explainer created successfully!');
      onClose();
    } catch (error: any) {
      console.error('Error creating explainer:', error);
      if (error?.message?.includes('violates safety guidelines')) {
        toast.error('Content blocked: Violates safety guidelines', {
          description: 'Your content was flagged by our AI safety system. Please review our content policy.',
          duration: 5000,
        });
      } else if (error?.message?.includes('limit reached')) {
        toast.error('Free user limit reached', {
          description: 'Upgrade to a paid plan to create more explainers.',
          duration: 5000,
        });
      } else {
        toast.error('Error creating explainer');
      }
    }
  };

  const handleSubmitWithAcknowledgment = () => {
    setShowResponsibilityModal(true);
  };

  const handleResponsibilityAccept = () => {
    setShowResponsibilityModal(false);
    handleSubmit();
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setAudioBlob(file);
      toast.success('Audio file uploaded');
    }
  };

  const handleRecordToggle = async () => {
    if (isRecording) {
      setIsRecording(false);
      toast.info('Recording stopped');
    } else {
      setIsRecording(true);
      toast.info('Recording started...');
    }
  };

  const handleAiSuggestionApply = (suggestion: string) => {
    setContent(prev => prev ? `${prev}\n\n${suggestion}` : suggestion);
  };

  return (
    <>
      <Dialog open onOpenChange={onClose}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-purple-900/95 to-pink-900/95 border-purple-500/30 backdrop-blur-xl">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <div>
                <DialogTitle className="text-2xl text-white flex items-center gap-2">
                  <Sparkles className="h-6 w-6 text-purple-300" />
                  Create New Video Explainer
                </DialogTitle>
                <DialogDescription className="text-purple-200">
                  Create multi-language explanations for your video
                </DialogDescription>
              </div>
              {isAiEnabled && (
                <Button
                  onClick={() => setShowAiAssistant(!showAiAssistant)}
                  variant="outline"
                  size="sm"
                  className="border-purple-500/30 bg-white/10 text-white hover:bg-white/20"
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  {showAiAssistant ? 'Hide' : 'Show'} AI
                </Button>
              )}
            </div>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Video Selection */}
            <div className="space-y-2">
              <Label htmlFor="video" className="text-white">Select Video</Label>
              <Select value={selectedVideoId} onValueChange={setSelectedVideoId}>
                <SelectTrigger className="bg-white/10 border-white/20 text-white">
                  <SelectValue placeholder="Choose a video" />
                </SelectTrigger>
                <SelectContent className="bg-purple-900 border-purple-500/30">
                  {videos?.map((video) => (
                    <SelectItem key={video.id.toString()} value={video.id.toString()}>
                      {video.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Voice Options */}
            <Tabs value={voiceOption} onValueChange={(v) => setVoiceOption(v as 'ai' | 'clone')}>
              <TabsList className="grid w-full grid-cols-2 bg-white/10">
                <TabsTrigger value="ai" className="data-[state=active]:bg-purple-600">
                  <Volume2 className="mr-2 h-4 w-4" />
                  AI Voice
                </TabsTrigger>
                <TabsTrigger value="clone" className="data-[state=active]:bg-purple-600">
                  <Mic className="mr-2 h-4 w-4" />
                  Clone Voice
                </TabsTrigger>
              </TabsList>

              <TabsContent value="ai" className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white">Language</Label>
                    <Select value={language} onValueChange={setLanguage}>
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-purple-900 border-purple-500/30">
                        {languages?.map((lang) => (
                          <SelectItem key={lang} value={lang}>
                            {lang}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white">Voice Type</Label>
                    <Select value={voiceType} onValueChange={setVoiceType}>
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-purple-900 border-purple-500/30">
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="neutral">Neutral</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white">Tone</Label>
                    <Select value={tone} onValueChange={setTone}>
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-purple-900 border-purple-500/30">
                        <SelectItem value="professional">Professional</SelectItem>
                        <SelectItem value="casual">Casual</SelectItem>
                        <SelectItem value="enthusiastic">Enthusiastic</SelectItem>
                        <SelectItem value="calm">Calm</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white">Accent</Label>
                    <Select value={accent} onValueChange={setAccent}>
                      <SelectTrigger className="bg-white/10 border-white/20 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-purple-900 border-purple-500/30">
                        <SelectItem value="Indian">Indian</SelectItem>
                        <SelectItem value="American">American</SelectItem>
                        <SelectItem value="British">British</SelectItem>
                        <SelectItem value="Australian">Australian</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="clone" className="space-y-4 mt-4">
                <Card className="border-purple-500/30 bg-white/5">
                  <CardContent className="p-6 space-y-4">
                    <div className="space-y-2">
                      <Label className="text-white">Voice Profile Name</Label>
                      <Input
                        value={voiceProfileName}
                        onChange={(e) => setVoiceProfileName(e.target.value)}
                        placeholder="My Voice"
                        className="bg-white/10 border-white/20 text-white placeholder:text-purple-300"
                      />
                    </div>

                    <div className="flex gap-3">
                      <Button
                        type="button"
                        onClick={handleRecordToggle}
                        variant={isRecording ? 'destructive' : 'outline'}
                        className="flex-1 border-white/20 bg-white/10 text-white hover:bg-white/20"
                      >
                        <Mic className="mr-2 h-4 w-4" />
                        {isRecording ? 'Stop Recording' : 'Record'}
                      </Button>

                      <Button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        variant="outline"
                        className="flex-1 border-white/20 bg-white/10 text-white hover:bg-white/20"
                      >
                        <Upload className="mr-2 h-4 w-4" />
                        Upload
                      </Button>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="audio/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </div>

                    {audioBlob && (
                      <div className="p-3 bg-green-500/20 border border-green-500/30 rounded-lg">
                        <p className="text-sm text-green-200">
                          ✓ Audio sample ready
                        </p>
                      </div>
                    )}

                    <p className="text-xs text-purple-300">
                      For best results, record 10-30 seconds of clear audio
                    </p>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Content */}
            <div className="space-y-2">
              <Label htmlFor="content" className="text-white">Explanation Content</Label>
              <Textarea
                id="content"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Write your video explanation..."
                rows={6}
                className="bg-white/10 border-white/20 text-white placeholder:text-purple-300 resize-none"
              />
              <p className="text-xs text-purple-300">
                {content.length} characters
              </p>
            </div>

            {isAiEnabled && showAiAssistant && (
              <AiPromptAssistant
                context={content}
                onSuggestionApply={handleAiSuggestionApply}
                placeholder="Ask AI to help with your video explanation..."
                mode="explainer"
              />
            )}

            {/* Actions */}
            <div className="flex gap-3 pt-4">
              <Button
                onClick={onClose}
                variant="outline"
                className="flex-1 border-white/20 bg-white/10 text-white hover:bg-white/20"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSubmitWithAcknowledgment}
                disabled={createExplainer.isPending || createVoiceProfile.isPending}
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                {createExplainer.isPending || createVoiceProfile.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" />
                    Create Explainer
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <ContentResponsibilityModal
        open={showResponsibilityModal}
        onAccept={handleResponsibilityAccept}
        onCancel={() => setShowResponsibilityModal(false)}
      />
    </>
  );
}


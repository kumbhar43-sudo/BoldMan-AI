import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BookOpen, Users, Film, Edit, Trash2 } from 'lucide-react';
import type { Story } from '../backend';
import { useDeleteStory } from '../hooks/useQueries';
import { toast } from 'sonner';

interface StoryCardProps {
  story: Story;
  onEdit: (story: Story) => void;
}

export default function StoryCard({ story, onEdit }: StoryCardProps) {
  const deleteStory = useDeleteStory();

  const handleDelete = async () => {
    if (!confirm('क्या आप वाकई इस कहानी को हटाना चाहते हैं?')) return;

    try {
      await deleteStory.mutateAsync(story.storyId);
      toast.success('कहानी सफलतापूर्वक हटाई गई');
    } catch (error) {
      toast.error('कहानी हटाने में त्रुटि');
      console.error(error);
    }
  };

  const formatDate = (timestamp: bigint) => {
    const date = new Date(Number(timestamp) / 1000000);
    return date.toLocaleDateString('hi-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg hover:bg-white/10 transition-all group">
      <CardContent className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-purple-600 to-pink-600">
            <BookOpen className="h-6 w-6 text-white" />
          </div>
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => onEdit(story)}
              className="text-white hover:bg-white/20"
            >
              <Edit className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleDelete}
              disabled={deleteStory.isPending}
              className="text-red-400 hover:bg-red-500/20"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <h3 className="text-lg font-semibold text-white mb-2 line-clamp-2">
          {story.title}
        </h3>

        {story.description && (
          <p className="text-sm text-purple-200 mb-4 line-clamp-2">
            {story.description}
          </p>
        )}

        <div className="flex flex-wrap gap-2 mb-4">
          <Badge variant="secondary" className="flex items-center gap-1">
            <Users className="h-3 w-3" />
            {story.characters.length} कैरेक्टर
          </Badge>
          <Badge variant="secondary" className="flex items-center gap-1">
            <Film className="h-3 w-3" />
            {story.scenes.length} सीन
          </Badge>
        </div>

        <div className="text-xs text-purple-300">
          बनाया गया: {formatDate(story.createdAt)}
        </div>
      </CardContent>
    </Card>
  );
}

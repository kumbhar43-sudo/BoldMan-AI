import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Upload, FileText, Image as ImageIcon, Loader2, Mic, Type, ImagePlus } from 'lucide-react';
import { useCreateVideoProject } from '../hooks/useQueries';
import { ExternalBlob } from '../backend';
import { toast } from 'sonner';
import ContentResponsibilityModal from './ContentResponsibilityModal';

interface CreateVideoDialogProps {
  onClose: () => void;
}

export default function CreateVideoDialog({ onClose }: CreateVideoDialogProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [scriptText, setScriptText] = useState('');
  const [textPrompt, setTextPrompt] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [showResponsibilityModal, setShowResponsibilityModal] = useState(false);
  const [pendingAction, setPendingAction] = useState<(() => void) | null>(null);
  const [customThumbnail, setCustomThumbnail] = useState<File | null>(null);
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const createVideo = useCreateVideoProject();

  const handleResponsibilityAccept = () => {
    setShowResponsibilityModal(false);
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  };

  const handleResponsibilityCancel = () => {
    setShowResponsibilityModal(false);
    setPendingAction(null);
  };

  const handleThumbnailUpload = (file: File) => {
    setCustomThumbnail(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setThumbnailPreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleFileUpload = async (file: File) => {
    setIsUploading(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const uint8Array = new Uint8Array(arrayBuffer);
      const blob = ExternalBlob.fromBytes(uint8Array).withUploadProgress((percentage) => {
        setUploadProgress(percentage);
      });

      await createVideo.mutateAsync({
        title: title || 'New Video',
        description: description || '',
        videoFile: blob,
        language: 'en',
        thumbnail: customThumbnail,
      });

      toast.success('Video project created successfully!');
      onClose();
    } catch (error: any) {
      if (error?.message?.includes('violates safety guidelines')) {
        toast.error('Content blocked: Violates safety guidelines', {
          description: 'Your content was flagged by our AI safety system. Please review our content policy.',
          duration: 5000,
        });
      } else if (error?.message?.includes('limit reached')) {
        toast.error('Free user limit reached', {
          description: 'Upgrade to a paid plan to continue creating videos.',
          duration: 5000,
        });
      } else {
        toast.error('Error uploading video');
      }
      console.error(error);
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const handleTextPromptSubmit = async () => {
    if (!textPrompt.trim()) {
      toast.error('Please enter a text prompt');
      return;
    }

    const placeholderData = new TextEncoder().encode(textPrompt);
    const blob = ExternalBlob.fromBytes(placeholderData);

    try {
      await createVideo.mutateAsync({
        title: title || 'Video from Text',
        description: description || textPrompt.substring(0, 100),
        videoFile: blob,
        language: 'en',
        thumbnail: customThumbnail,
      });

      toast.success('Video project created from text!');
      onClose();
    } catch (error: any) {
      if (error?.message?.includes('violates safety guidelines')) {
        toast.error('Content blocked: Violates safety guidelines', {
          description: 'Your content was flagged by our AI safety system.',
          duration: 5000,
        });
      } else if (error?.message?.includes('limit reached')) {
        toast.error('Free user limit reached', {
          description: 'Upgrade to a paid plan to continue.',
          duration: 5000,
        });
      } else {
        toast.error('Error creating project');
      }
      console.error(error);
    }
  };

  const handleScriptSubmit = async () => {
    if (!scriptText.trim()) {
      toast.error('Please enter a script');
      return;
    }

    const placeholderData = new TextEncoder().encode(scriptText);
    const blob = ExternalBlob.fromBytes(placeholderData);

    try {
      await createVideo.mutateAsync({
        title: title || 'Video from Script',
        description: description || scriptText.substring(0, 100),
        videoFile: blob,
        language: 'en',
        thumbnail: customThumbnail,
      });

      toast.success('Video project created from script!');
      onClose();
    } catch (error: any) {
      if (error?.message?.includes('violates safety guidelines')) {
        toast.error('Content blocked: Violates safety guidelines', {
          description: 'Your content was flagged by our AI safety system.',
          duration: 5000,
        });
      } else if (error?.message?.includes('limit reached')) {
        toast.error('Free user limit reached', {
          description: 'Upgrade to a paid plan to continue.',
          duration: 5000,
        });
      } else {
        toast.error('Error creating project');
      }
      console.error(error);
    }
  };

  const handleVoiceSubmit = async () => {
    if (!audioBlob) {
      toast.error('Please record or upload audio');
      return;
    }

    const arrayBuffer = await audioBlob.arrayBuffer();
    const uint8Array = new Uint8Array(arrayBuffer);
    const blob = ExternalBlob.fromBytes(uint8Array);

    try {
      await createVideo.mutateAsync({
        title: title || 'Video from Voice',
        description: description || 'Voice-generated video',
        videoFile: blob,
        language: 'en',
        thumbnail: customThumbnail,
      });

      toast.success('Video project created from voice!');
      onClose();
    } catch (error: any) {
      if (error?.message?.includes('violates safety guidelines')) {
        toast.error('Content blocked: Violates safety guidelines');
      } else if (error?.message?.includes('limit reached')) {
        toast.error('Free user limit reached');
      } else {
        toast.error('Error creating project');
      }
      console.error(error);
    }
  };

  const handleTextPromptWithAcknowledgment = () => {
    setPendingAction(() => handleTextPromptSubmit);
    setShowResponsibilityModal(true);
  };

  const handleScriptSubmitWithAcknowledgment = () => {
    setPendingAction(() => handleScriptSubmit);
    setShowResponsibilityModal(true);
  };

  const handleVoiceSubmitWithAcknowledgment = () => {
    setPendingAction(() => handleVoiceSubmit);
    setShowResponsibilityModal(true);
  };

  const handleFileUploadWithAcknowledgment = (file: File) => {
    setPendingAction(() => () => handleFileUpload(file));
    setShowResponsibilityModal(true);
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      const chunks: Blob[] = [];

      mediaRecorder.ondataavailable = (e) => chunks.push(e.data);
      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        setAudioBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);

      setTimeout(() => {
        if (mediaRecorder.state === 'recording') {
          mediaRecorder.stop();
          setIsRecording(false);
        }
      }, 30000);
    } catch (error) {
      toast.error('Microphone access denied');
      console.error(error);
    }
  };

  const stopRecording = () => {
    setIsRecording(false);
  };

  return (
    <>
      <Dialog open={true} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl bg-gradient-to-br from-purple-900 to-indigo-900 border-purple-500/50 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl text-white">Create New Video</DialogTitle>
            <DialogDescription className="text-purple-200">
              Create your video from text, script, image, voice, or file upload
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <Label htmlFor="title" className="text-white">Video Title *</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter a custom title for your video"
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-white">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Add a description for your video"
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50 min-h-20"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-white">Custom Thumbnail (Optional)</Label>
              <div className="flex gap-4 items-center">
                <div className="flex-1">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleThumbnailUpload(file);
                    }}
                    className="hidden"
                    id="thumbnail-upload"
                  />
                  <Button
                    asChild
                    variant="outline"
                    className="w-full border-white/20 bg-white/10 text-white hover:bg-white/20"
                  >
                    <label htmlFor="thumbnail-upload" className="cursor-pointer">
                      <ImagePlus className="mr-2 h-4 w-4" />
                      Upload Thumbnail
                    </label>
                  </Button>
                </div>
                {thumbnailPreview && (
                  <div className="w-24 h-16 rounded border border-white/20 overflow-hidden">
                    <img src={thumbnailPreview} alt="Thumbnail preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>
              <p className="text-xs text-purple-300">
                Upload a custom thumbnail or let AI auto-generate one from your video
              </p>
            </div>

            <Tabs defaultValue="text" className="mt-6">
              <TabsList className="bg-white/10 border border-white/20 w-full grid grid-cols-5">
                <TabsTrigger value="text" className="data-[state=active]:bg-purple-600">
                  <Type className="mr-2 h-4 w-4" />
                  Text
                </TabsTrigger>
                <TabsTrigger value="script" className="data-[state=active]:bg-purple-600">
                  <FileText className="mr-2 h-4 w-4" />
                  Script
                </TabsTrigger>
                <TabsTrigger value="image" className="data-[state=active]:bg-purple-600">
                  <ImageIcon className="mr-2 h-4 w-4" />
                  Image
                </TabsTrigger>
                <TabsTrigger value="voice" className="data-[state=active]:bg-purple-600">
                  <Mic className="mr-2 h-4 w-4" />
                  Voice
                </TabsTrigger>
                <TabsTrigger value="upload" className="data-[state=active]:bg-purple-600">
                  <Upload className="mr-2 h-4 w-4" />
                  Upload
                </TabsTrigger>
              </TabsList>

              <TabsContent value="text" className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-white">Text Prompt</Label>
                  <Textarea
                    value={textPrompt}
                    onChange={(e) => setTextPrompt(e.target.value)}
                    placeholder="Describe your video in text... e.g., 'A cinematic video about a hero's journey through mountains'"
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 min-h-32"
                  />
                </div>
                <Button
                  onClick={handleTextPromptWithAcknowledgment}
                  disabled={createVideo.isPending || !textPrompt.trim()}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  {createVideo.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    'Create Video from Text'
                  )}
                </Button>
              </TabsContent>

              <TabsContent value="script" className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-white">Write Your Script</Label>
                  <Textarea
                    value={scriptText}
                    onChange={(e) => setScriptText(e.target.value)}
                    placeholder="Write your complete script or story here..."
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 min-h-40"
                  />
                </div>
                <Button
                  onClick={handleScriptSubmitWithAcknowledgment}
                  disabled={createVideo.isPending || !scriptText.trim()}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  {createVideo.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    'Create Video from Script'
                  )}
                </Button>
              </TabsContent>

              <TabsContent value="image" className="space-y-4">
                <div className="rounded-lg border-2 border-dashed border-white/20 bg-white/5 p-12 text-center">
                  <ImageIcon className="mx-auto h-12 w-12 text-purple-300 mb-4" />
                  <p className="text-white mb-2">Upload Image</p>
                  <p className="text-sm text-purple-200 mb-4">
                    PNG, JPG or GIF (max 10MB) - AI will generate video from your image
                  </p>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUploadWithAcknowledgment(file);
                    }}
                    className="hidden"
                    id="image-upload"
                  />
                  <Button asChild variant="outline" className="border-white/20 bg-white/10 text-white hover:bg-white/20">
                    <label htmlFor="image-upload" className="cursor-pointer">
                      Choose Image
                    </label>
                  </Button>
                </div>
              </TabsContent>

              <TabsContent value="voice" className="space-y-4">
                <div className="rounded-lg border-2 border-dashed border-white/20 bg-white/5 p-8 text-center">
                  <Mic className="mx-auto h-12 w-12 text-purple-300 mb-4" />
                  <p className="text-white mb-2">Record or Upload Voice</p>
                  <p className="text-sm text-purple-200 mb-4">
                    Record your voice or upload an audio file to generate video
                  </p>
                  <div className="flex gap-3 justify-center mb-4">
                    <Button
                      onClick={isRecording ? stopRecording : startRecording}
                      variant="outline"
                      className={`border-white/20 ${isRecording ? 'bg-red-600 text-white' : 'bg-white/10 text-white'} hover:bg-white/20`}
                    >
                      <Mic className="mr-2 h-4 w-4" />
                      {isRecording ? 'Stop Recording' : 'Start Recording'}
                    </Button>
                    <input
                      type="file"
                      accept="audio/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) setAudioBlob(file);
                      }}
                      className="hidden"
                      id="audio-upload"
                    />
                    <Button asChild variant="outline" className="border-white/20 bg-white/10 text-white hover:bg-white/20">
                      <label htmlFor="audio-upload" className="cursor-pointer">
                        <Upload className="mr-2 h-4 w-4" />
                        Upload Audio
                      </label>
                    </Button>
                  </div>
                  {audioBlob && (
                    <div className="mb-4">
                      <p className="text-sm text-green-400 mb-2">✓ Audio ready</p>
                      <Button
                        onClick={handleVoiceSubmitWithAcknowledgment}
                        disabled={createVideo.isPending}
                        className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                      >
                        {createVideo.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Creating...
                          </>
                        ) : (
                          'Create Video from Voice'
                        )}
                      </Button>
                    </div>
                  )}
                </div>
              </TabsContent>

              <TabsContent value="upload" className="space-y-4">
                <div className="rounded-lg border-2 border-dashed border-white/20 bg-white/5 p-12 text-center">
                  <Upload className="mx-auto h-12 w-12 text-purple-300 mb-4" />
                  <p className="text-white mb-2">Upload Video File</p>
                  <p className="text-sm text-purple-200 mb-4">
                    MP4, MOV or AVI (max 100MB)
                  </p>
                  <input
                    type="file"
                    accept="video/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUploadWithAcknowledgment(file);
                    }}
                    className="hidden"
                    id="video-upload"
                    disabled={isUploading}
                  />
                  <Button
                    asChild
                    variant="outline"
                    className="border-white/20 bg-white/10 text-white hover:bg-white/20"
                    disabled={isUploading}
                  >
                    <label htmlFor="video-upload" className="cursor-pointer">
                      {isUploading ? 'Uploading...' : 'Choose File'}
                    </label>
                  </Button>
                  {isUploading && (
                    <div className="mt-4">
                      <div className="w-full bg-white/10 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-purple-600 to-pink-600 h-2 rounded-full transition-all"
                          style={{ width: `${uploadProgress}%` }}
                        />
                      </div>
                      <p className="text-sm text-purple-200 mt-2">{uploadProgress}% complete</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </DialogContent>
      </Dialog>

      <ContentResponsibilityModal
        open={showResponsibilityModal}
        onAccept={handleResponsibilityAccept}
        onCancel={handleResponsibilityCancel}
      />
    </>
  );
}

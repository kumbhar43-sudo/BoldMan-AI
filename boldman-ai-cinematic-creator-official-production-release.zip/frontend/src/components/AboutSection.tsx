import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Sparkles, Video, Users, Globe, Shield, Award, Zap, Heart } from 'lucide-react';

export default function AboutSection() {
  return (
    <div className="space-y-6">
      <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <Sparkles className="h-6 w-6 text-purple-400" />
            About BoldMan AI Cinematic Creator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Overview */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
              <Video className="h-5 w-5 text-purple-400" />
              Platform Overview
            </h3>
            <p className="text-purple-200 leading-relaxed">
              BoldMan AI Cinematic Creator is a production-ready AI-powered platform that enables users to generate 
              4K-capable cinematic videos from text, scripts, or images. With automated scene analysis, voice-over, 
              and 3D character animation, you can create professional-quality videos with multi-character stories, 
              scene-by-scene creation, and comprehensive video explanation capabilities.
            </p>
          </div>

          {/* Key Features */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
              <Zap className="h-5 w-5 text-purple-400" />
              Key Features
            </h3>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="flex items-start gap-2">
                <Video className="h-4 w-4 text-purple-400 mt-1 shrink-0" />
                <div>
                  <p className="text-white font-medium">4K Video Generation</p>
                  <p className="text-sm text-purple-300">Professional cinematic quality output</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Users className="h-4 w-4 text-purple-400 mt-1 shrink-0" />
                <div>
                  <p className="text-white font-medium">Multi-Character Stories</p>
                  <p className="text-sm text-purple-300">Create complex narratives with multiple characters</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Globe className="h-4 w-4 text-purple-400 mt-1 shrink-0" />
                <div>
                  <p className="text-white font-medium">Multi-Language Support</p>
                  <p className="text-sm text-purple-300">Voice-over in multiple languages and accents</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Sparkles className="h-4 w-4 text-purple-400 mt-1 shrink-0" />
                <div>
                  <p className="text-white font-medium">AI Prompt Assistant</p>
                  <p className="text-sm text-purple-300">Smart suggestions for content creation</p>
                </div>
              </div>
            </div>
          </div>

          {/* Deployment & Rights */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-3 flex items-center gap-2">
              <Shield className="h-5 w-5 text-purple-400" />
              Deployment & Rights
            </h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-purple-200">
                <Award className="h-4 w-4 text-green-400" />
                <span>Official production deployment on Internet Computer network</span>
              </div>
              <div className="flex items-center gap-2 text-purple-200">
                <Globe className="h-4 w-4 text-blue-400" />
                <span>Custom domain accessible at <strong className="text-blue-300">boldman.ai</strong></span>
              </div>
              <div className="flex items-center gap-2 text-purple-200">
                <Shield className="h-4 w-4 text-purple-400" />
                <span>Full commercial rights ownership for all generated content</span>
              </div>
              <div className="flex items-center gap-2 text-purple-200">
                <Video className="h-4 w-4 text-pink-400" />
                <span>Cross-platform PWA support (Web, Android, iOS, Windows)</span>
              </div>
            </div>
          </div>

          {/* Professional Credit */}
          <div className="border-t border-white/10 pt-4 mt-6">
            <div className="flex flex-col items-center gap-3">
              <p className="flex items-center gap-2 text-sm text-purple-200">
                © 2025. Built with{' '}
                <Heart className="h-4 w-4 fill-pink-500 text-pink-500 animate-pulse" /> using
              </p>
              <a
                href="https://caffeine.ai"
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-2 rounded-lg bg-gradient-to-r from-purple-600/20 to-pink-600/20 px-4 py-2 transition-all hover:from-purple-600/30 hover:to-pink-600/30 hover:shadow-glow"
              >
                <span className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 group-hover:from-purple-300 group-hover:to-pink-300">
                  caffeine.ai
                </span>
              </a>
              <p className="text-xs italic animate-shimmer bg-gradient-to-r from-gray-500 via-gray-300 to-gray-500 bg-[length:200%_auto] bg-clip-text text-transparent">
                Creative Support by Caffeine AI
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

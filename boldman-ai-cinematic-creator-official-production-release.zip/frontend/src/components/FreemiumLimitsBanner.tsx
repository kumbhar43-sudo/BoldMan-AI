import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { AlertCircle, Zap, Clock, Video, MessageSquare } from 'lucide-react';
import { useGetFreemiumLimits } from '../hooks/useQueries';
import { useState } from 'react';
import SubscriptionDialog from './SubscriptionDialog';

export default function FreemiumLimitsBanner() {
  const { data: limits } = useGetFreemiumLimits();
  const [showSubscription, setShowSubscription] = useState(false);

  if (!limits || limits.subscriptionTier !== 'free') {
    return null;
  }

  const promptPercentage = (Number(limits.currentPromptCount) / Number(limits.maxPrompts)) * 100;
  const durationPercentage = (Number(limits.currentVideoDuration) / Number(limits.maxVideoDuration)) * 100;
  const explainerPercentage = (Number(limits.currentExplainers) / Number(limits.maxExplainers)) * 100;

  const isNearLimit = promptPercentage > 80 || durationPercentage > 80 || explainerPercentage > 80;

  return (
    <>
      <Card className={`border-2 ${isNearLimit ? 'border-amber-500/50 bg-amber-500/10' : 'border-purple-500/30 bg-white/5'} backdrop-blur-lg mb-6`}>
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${isNearLimit ? 'bg-amber-500/20' : 'bg-purple-500/20'}`}>
                <AlertCircle className={`h-6 w-6 ${isNearLimit ? 'text-amber-400' : 'text-purple-400'}`} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-white">Free Trial Plan</h3>
                <p className="text-sm text-purple-200">Upgrade to unlock unlimited features</p>
              </div>
            </div>
            <Button
              onClick={() => setShowSubscription(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <Zap className="mr-2 h-4 w-4" />
              Upgrade Now
            </Button>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4 text-purple-400" />
                  <span className="text-white">AI Prompts</span>
                </div>
                <span className="text-purple-200">
                  {Number(limits.currentPromptCount)}/{Number(limits.maxPrompts)}
                </span>
              </div>
              <Progress value={promptPercentage} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <Video className="h-4 w-4 text-purple-400" />
                  <span className="text-white">Video Duration</span>
                </div>
                <span className="text-purple-200">
                  {Math.floor(Number(limits.currentVideoDuration) / 60)}m/{Math.floor(Number(limits.maxVideoDuration) / 60)}m
                </span>
              </div>
              <Progress value={durationPercentage} className="h-2" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-purple-400" />
                  <span className="text-white">Explainers</span>
                </div>
                <span className="text-purple-200">
                  {Number(limits.currentExplainers)}/{Number(limits.maxExplainers)}
                </span>
              </div>
              <Progress value={explainerPercentage} className="h-2" />
            </div>
          </div>

          {isNearLimit && (
            <div className="mt-4 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30">
              <p className="text-sm text-amber-100 flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                You're approaching your free plan limits. Upgrade to continue creating without restrictions.
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {showSubscription && (
        <SubscriptionDialog
          open={showSubscription}
          onClose={() => setShowSubscription(false)}
        />
      )}
    </>
  );
}


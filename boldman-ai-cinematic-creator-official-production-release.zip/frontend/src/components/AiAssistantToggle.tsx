import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Sparkles, Shield } from 'lucide-react';
import { useToggleAiPromptAssistant, useIsPromptAssistantEnabled } from '../hooks/useQueries';
import { toast } from 'sonner';

export default function AiAssistantToggle() {
  const { data: isEnabled, isLoading } = useIsPromptAssistantEnabled();
  const toggleAssistant = useToggleAiPromptAssistant();

  const handleToggle = async (checked: boolean) => {
    try {
      await toggleAssistant.mutateAsync(checked);
      toast.success(checked ? 'AI Assistant enabled' : 'AI Assistant disabled');
    } catch (error) {
      console.error('Error toggling AI assistant:', error);
      toast.error('Failed to update settings');
    }
  };

  if (isLoading) {
    return null;
  }

  return (
    <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
      <CardContent className="p-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 space-y-2">
            <div className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-purple-400" />
              <Label htmlFor="ai-assistant" className="text-white font-semibold text-base cursor-pointer">
                AI Prompt Assistant
              </Label>
            </div>
            <p className="text-purple-200 text-sm">
              Enable AI-powered suggestions and content refinement across Script Editor, Story Builder, and Video Explainer
            </p>
            <div className="flex items-center gap-2 text-xs text-purple-300 mt-3">
              <Shield className="h-4 w-4" />
              <span>Your privacy is protected. Toggle off anytime.</span>
            </div>
          </div>
          <Switch
            id="ai-assistant"
            checked={isEnabled ?? true}
            onCheckedChange={handleToggle}
            disabled={toggleAssistant.isPending}
            className="data-[state=checked]:bg-purple-600"
          />
        </div>
      </CardContent>
    </Card>
  );
}

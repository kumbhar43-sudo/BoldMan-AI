import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, User } from 'lucide-react';
import type { Character, Voice, Avatar } from '../backend';
import { ExternalBlob } from '../backend';

interface CharacterManagerProps {
  characters: Character[];
  onCharactersChange: (characters: Character[]) => void;
}

export default function CharacterManager({ characters, onCharactersChange }: CharacterManagerProps) {
  const [showForm, setShowForm] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [name, setName] = useState('');
  const [language, setLanguage] = useState('hi');
  const [accent, setAccent] = useState('indian');
  const [gender, setGender] = useState('male');
  const [tone, setTone] = useState('neutral');

  const handleAddCharacter = () => {
    if (!name.trim()) return;

    const placeholderImage = ExternalBlob.fromBytes(new Uint8Array([0]));

    const newCharacter: Character = {
      id: BigInt(Date.now()),
      name: name.trim(),
      language,
      accent,
      voice: {
        voiceId: BigInt(Date.now()),
        name: `${name} की आवाज़`,
        language,
        accent,
        gender,
        tone,
      },
      avatar: {
        avatarId: BigInt(Date.now()),
        name: `${name} अवतार`,
        image: placeholderImage,
        style: 'realistic',
      },
    };

    if (editingIndex !== null) {
      const updated = [...characters];
      updated[editingIndex] = newCharacter;
      onCharactersChange(updated);
      setEditingIndex(null);
    } else {
      onCharactersChange([...characters, newCharacter]);
    }

    resetForm();
  };

  const handleEdit = (index: number) => {
    const char = characters[index];
    setName(char.name);
    setLanguage(char.language);
    setAccent(char.accent);
    setGender(char.voice.gender);
    setTone(char.voice.tone);
    setEditingIndex(index);
    setShowForm(true);
  };

  const handleDelete = (index: number) => {
    onCharactersChange(characters.filter((_, i) => i !== index));
  };

  const resetForm = () => {
    setName('');
    setLanguage('hi');
    setAccent('indian');
    setGender('male');
    setTone('neutral');
    setShowForm(false);
    setEditingIndex(null);
  };

  return (
    <div className="space-y-4">
      {characters.length > 0 && (
        <div className="grid gap-4 md:grid-cols-2">
          {characters.map((char, index) => (
            <Card key={char.id.toString()} className="border-purple-500/30 bg-white/5">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex-shrink-0">
                    <User className="h-6 w-6 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-white font-semibold truncate">{char.name}</h4>
                    <p className="text-sm text-purple-200">
                      {char.voice.gender === 'male' ? 'पुरुष' : 'महिला'} • {char.language === 'hi' ? 'हिंदी' : char.language}
                    </p>
                    <p className="text-xs text-purple-300">
                      {char.accent} • {char.voice.tone}
                    </p>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(index)}
                      className="text-white hover:bg-white/20 h-8 w-8 p-0"
                    >
                      <User className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(index)}
                      className="text-red-400 hover:bg-red-500/20 h-8 w-8 p-0"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {!showForm ? (
        <Button
          onClick={() => setShowForm(true)}
          variant="outline"
          className="w-full border-white/20 bg-white/10 text-white hover:bg-white/20"
        >
          <Plus className="mr-2 h-4 w-4" />
          नया कैरेक्टर जोड़ें
        </Button>
      ) : (
        <Card className="border-purple-500/30 bg-white/5">
          <CardContent className="p-6 space-y-4">
            <h4 className="text-white font-semibold">
              {editingIndex !== null ? 'कैरेक्टर संपादित करें' : 'नया कैरेक्टर'}
            </h4>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="text-white">नाम *</Label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="कैरेक्टर का नाम"
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">भाषा</Label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hi">हिंदी</SelectItem>
                    <SelectItem value="en">अंग्रेज़ी</SelectItem>
                    <SelectItem value="mr">मराठी</SelectItem>
                    <SelectItem value="ta">तमिल</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-white">लहजा</Label>
                <Select value={accent} onValueChange={setAccent}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="indian">भारतीय</SelectItem>
                    <SelectItem value="british">ब्रिटिश</SelectItem>
                    <SelectItem value="american">अमेरिकी</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-white">लिंग</Label>
                <Select value={gender} onValueChange={setGender}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">पुरुष</SelectItem>
                    <SelectItem value="female">महिला</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label className="text-white">आवाज़ का स्वर</Label>
                <Select value={tone} onValueChange={setTone}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="neutral">सामान्य</SelectItem>
                    <SelectItem value="friendly">मित्रवत</SelectItem>
                    <SelectItem value="serious">गंभीर</SelectItem>
                    <SelectItem value="cheerful">प्रसन्न</SelectItem>
                    <SelectItem value="dramatic">नाटकीय</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex gap-2">
              <Button
                onClick={handleAddCharacter}
                disabled={!name.trim()}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                {editingIndex !== null ? 'अपडेट करें' : 'जोड़ें'}
              </Button>
              <Button
                onClick={resetForm}
                variant="outline"
                className="border-white/20 bg-white/10 text-white hover:bg-white/20"
              >
                रद्द करें
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

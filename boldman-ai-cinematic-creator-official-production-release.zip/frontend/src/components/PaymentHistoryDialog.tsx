import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Receipt, Download, Eye, Calendar, DollarSign, Heart } from 'lucide-react';
import { toast } from 'sonner';

interface PaymentTransaction {
  id: string;
  date: string;
  subscriptionType: string;
  totalAmount: number;
  ownerAmount: number;
  charityAmount: number;
  charityBreakdown: Array<{ name: string; amount: number; percentage: number }>;
  status: string;
  invoiceId: string;
  paymentMethod: string;
}

interface PaymentHistoryDialogProps {
  open: boolean;
  onClose: () => void;
}

export default function PaymentHistoryDialog({ open, onClose }: PaymentHistoryDialogProps) {
  const [selectedTransaction, setSelectedTransaction] = useState<PaymentTransaction | null>(null);

  // Mock data - will be replaced with actual backend data
  const transactions: PaymentTransaction[] = [
    {
      id: 'txn_001',
      date: '2025-01-15',
      subscriptionType: 'Full Subscription',
      totalAmount: 999,
      ownerAmount: 899.10,
      charityAmount: 99.90,
      charityBreakdown: [
        { name: 'Charity A', amount: 29.97, percentage: 30 },
        { name: 'Charity B', amount: 24.98, percentage: 25 },
        { name: 'Charity C', amount: 19.98, percentage: 20 },
        { name: 'Charity D', amount: 24.97, percentage: 25 },
      ],
      status: 'completed',
      invoiceId: 'INV-2025-001',
      paymentMethod: 'Visa •••• 4242',
    },
    {
      id: 'txn_002',
      date: '2025-01-10',
      subscriptionType: '10 Scene Upgrade',
      totalAmount: 399,
      ownerAmount: 359.10,
      charityAmount: 39.90,
      charityBreakdown: [
        { name: 'Charity A', amount: 11.97, percentage: 30 },
        { name: 'Charity B', amount: 9.98, percentage: 25 },
        { name: 'Charity C', amount: 7.98, percentage: 20 },
        { name: 'Charity D', amount: 9.97, percentage: 25 },
      ],
      status: 'completed',
      invoiceId: 'INV-2025-002',
      paymentMethod: 'Mastercard •••• 5555',
    },
  ];

  const handleViewInvoice = (transaction: PaymentTransaction) => {
    setSelectedTransaction(transaction);
    toast.success('Invoice details loaded');
  };

  const handleDownloadInvoice = (transaction: PaymentTransaction) => {
    toast.success(`Downloading invoice ${transaction.invoiceId}`);
  };

  const formatCurrency = (amount: number) => {
    return `$${(amount / 100).toFixed(2)}`;
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-hidden bg-gradient-to-br from-purple-950 via-indigo-950 to-blue-950 border-purple-500/30">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-white flex items-center gap-2">
            <Receipt className="h-6 w-6 text-purple-400" />
            Payment History & Invoices
          </DialogTitle>
          <DialogDescription className="text-purple-200">
            View all transactions and download tax-compliant invoices
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 md:grid-cols-2 h-[600px]">
          {/* Transaction List */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-white">Transactions</h3>
            <ScrollArea className="h-[540px] pr-4">
              <div className="space-y-3">
                {transactions.map((transaction) => (
                  <Card
                    key={transaction.id}
                    className={`border-purple-500/30 bg-white/5 backdrop-blur-lg cursor-pointer transition-all hover:bg-white/10 ${
                      selectedTransaction?.id === transaction.id ? 'ring-2 ring-purple-500' : ''
                    }`}
                    onClick={() => setSelectedTransaction(transaction)}
                  >
                    <CardContent className="p-4 space-y-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <p className="text-white font-semibold">{transaction.subscriptionType}</p>
                          <p className="text-sm text-purple-300 flex items-center gap-1 mt-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(transaction.date).toLocaleDateString()}
                          </p>
                        </div>
                        <Badge className="bg-green-600">
                          {transaction.status}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between pt-2 border-t border-purple-500/20">
                        <span className="text-purple-300 text-sm">Total</span>
                        <span className="text-white font-bold">
                          {formatCurrency(transaction.totalAmount)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-purple-300 text-sm flex items-center gap-1">
                          <Heart className="h-3 w-3 text-pink-400 fill-pink-400" />
                          Charity
                        </span>
                        <span className="text-pink-400 font-semibold">
                          {formatCurrency(transaction.charityAmount)}
                        </span>
                      </div>
                      <div className="flex gap-2 pt-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleViewInvoice(transaction);
                          }}
                          className="flex-1 border-purple-500/30 text-white hover:bg-white/10"
                        >
                          <Eye className="mr-1 h-3 w-3" />
                          View
                        </Button>
                        <Button
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDownloadInvoice(transaction);
                          }}
                          className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600"
                        >
                          <Download className="mr-1 h-3 w-3" />
                          PDF
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>

          {/* Invoice Details */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold text-white">Invoice Details</h3>
            {selectedTransaction ? (
              <ScrollArea className="h-[540px] pr-4">
                <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
                  <CardContent className="p-6 space-y-4">
                    <div className="text-center pb-4 border-b border-purple-500/20">
                      <h4 className="text-2xl font-bold text-white mb-1">
                        {selectedTransaction.invoiceId}
                      </h4>
                      <p className="text-purple-300">Tax-Compliant Invoice</p>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <p className="text-sm text-purple-300">Date</p>
                        <p className="text-white font-semibold">
                          {new Date(selectedTransaction.date).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                          })}
                        </p>
                      </div>

                      <div>
                        <p className="text-sm text-purple-300">Subscription Plan</p>
                        <p className="text-white font-semibold">
                          {selectedTransaction.subscriptionType}
                        </p>
                      </div>

                      <div>
                        <p className="text-sm text-purple-300">Payment Method</p>
                        <p className="text-white font-semibold">
                          {selectedTransaction.paymentMethod}
                        </p>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-purple-500/20 space-y-2">
                      <h5 className="text-white font-semibold mb-3">Payment Breakdown</h5>
                      
                      <div className="flex justify-between">
                        <span className="text-purple-300">Subtotal</span>
                        <span className="text-white">
                          {formatCurrency(selectedTransaction.totalAmount)}
                        </span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-purple-300">GST (18%)</span>
                        <span className="text-white">
                          {formatCurrency(Math.round(selectedTransaction.totalAmount * 0.18))}
                        </span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-purple-300">TDS (2%)</span>
                        <span className="text-white">
                          {formatCurrency(Math.round(selectedTransaction.totalAmount * 0.02))}
                        </span>
                      </div>

                      <div className="flex justify-between pt-2 border-t border-purple-500/20">
                        <span className="text-white font-semibold">Total Amount</span>
                        <span className="text-white font-bold text-lg">
                          {formatCurrency(selectedTransaction.totalAmount)}
                        </span>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-purple-500/20 space-y-2">
                      <h5 className="text-white font-semibold mb-3 flex items-center gap-2">
                        <DollarSign className="h-4 w-4 text-purple-400" />
                        Payment Distribution
                      </h5>
                      
                      <div className="flex justify-between">
                        <span className="text-purple-300">Owner Amount</span>
                        <span className="text-white font-semibold">
                          {formatCurrency(selectedTransaction.ownerAmount)}
                        </span>
                      </div>

                      <div className="flex justify-between">
                        <span className="text-pink-400 flex items-center gap-1">
                          <Heart className="h-3 w-3 fill-pink-400" />
                          Total Charity
                        </span>
                        <span className="text-pink-400 font-semibold">
                          {formatCurrency(selectedTransaction.charityAmount)}
                        </span>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-purple-500/20 space-y-2">
                      <h5 className="text-white font-semibold mb-3">Charity Breakdown</h5>
                      {selectedTransaction.charityBreakdown.map((charity, index) => (
                        <div key={index} className="flex justify-between items-center">
                          <div>
                            <p className="text-purple-200 text-sm">{charity.name}</p>
                            <p className="text-purple-400 text-xs">{charity.percentage}%</p>
                          </div>
                          <span className="text-white font-semibold">
                            {formatCurrency(Math.round(charity.amount * 100))}
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="pt-4">
                      <Button
                        onClick={() => handleDownloadInvoice(selectedTransaction)}
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                      >
                        <Download className="mr-2 h-4 w-4" />
                        Download PDF Invoice
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </ScrollArea>
            ) : (
              <div className="h-[540px] flex items-center justify-center">
                <div className="text-center text-purple-300">
                  <Receipt className="h-16 w-16 mx-auto mb-4 opacity-50" />
                  <p>Select a transaction to view invoice details</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

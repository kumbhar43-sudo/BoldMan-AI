import { useState } from 'react';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { LogOut, User, Sparkles, CreditCard, Receipt, Heart, Settings } from 'lucide-react';
import { useGetCallerUserProfile } from '../hooks/useQueries';
import SubscriptionDialog from './SubscriptionDialog';
import PaymentHistoryDialog from './PaymentHistoryDialog';
import CharityManagementDialog from './CharityManagementDialog';

export default function Header() {
  const { login, clear, loginStatus, identity } = useInternetIdentity();
  const { data: userProfile } = useGetCallerUserProfile();
  const queryClient = useQueryClient();
  const [showSubscriptionDialog, setShowSubscriptionDialog] = useState(false);
  const [showPaymentHistory, setShowPaymentHistory] = useState(false);
  const [showCharityManagement, setShowCharityManagement] = useState(false);

  const isAuthenticated = !!identity;
  const disabled = loginStatus === 'logging-in';

  const handleAuth = async () => {
    if (isAuthenticated) {
      await clear();
      queryClient.clear();
    } else {
      try {
        await login();
      } catch (error: any) {
        console.error('Login error:', error);
        if (error.message === 'User is already authenticated') {
          await clear();
          setTimeout(() => login(), 300);
        }
      }
    }
  };

  return (
    <>
      <header className="sticky top-0 z-50 border-b border-white/10 bg-black/30 backdrop-blur-xl">
        <div className="container mx-auto flex items-center justify-between px-4 py-3 lg:px-6">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img 
                src="/assets/generated/app-logo-transparent.dim_200x200.png" 
                alt="BoldMan Logo" 
                className="h-12 w-12 object-contain"
              />
              <div className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 shadow-glow">
                <Sparkles className="h-3 w-3 text-white" />
              </div>
            </div>
            <div>
              <h1 className="text-lg font-bold text-white lg:text-xl">
                BoldMan
              </h1>
              <p className="text-xs text-purple-300">Professional Edition</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isAuthenticated && (
              <>
                {userProfile && (
                  <div className="hidden items-center gap-2 rounded-full bg-white/10 px-4 py-2 backdrop-blur-sm sm:flex">
                    <User className="h-4 w-4 text-purple-300" />
                    <span className="text-sm font-medium text-white">{userProfile.name}</span>
                  </div>
                )}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="border-purple-500/30 bg-gradient-to-r from-purple-600/20 to-pink-600/20 text-white hover:from-purple-600/30 hover:to-pink-600/30"
                    >
                      <CreditCard className="mr-2 h-4 w-4" />
                      <span className="hidden sm:inline">Payments</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 bg-purple-950/95 border-purple-500/30 backdrop-blur-xl">
                    <DropdownMenuItem
                      onClick={() => setShowSubscriptionDialog(true)}
                      className="text-white hover:bg-white/10 cursor-pointer"
                    >
                      <CreditCard className="mr-2 h-4 w-4" />
                      Subscribe
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => setShowPaymentHistory(true)}
                      className="text-white hover:bg-white/10 cursor-pointer"
                    >
                      <Receipt className="mr-2 h-4 w-4" />
                      Payment History
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-purple-500/20" />
                    <DropdownMenuItem
                      onClick={() => setShowCharityManagement(true)}
                      className="text-white hover:bg-white/10 cursor-pointer"
                    >
                      <Heart className="mr-2 h-4 w-4 text-pink-400 fill-pink-400" />
                      Charity Settings
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            )}
            <Button
              onClick={handleAuth}
              disabled={disabled}
              variant={isAuthenticated ? 'outline' : 'default'}
              size="sm"
              className={
                isAuthenticated
                  ? 'border-white/20 bg-white/10 text-white hover:bg-white/20'
                  : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-glow hover:from-purple-700 hover:to-pink-700 hover:shadow-glow-lg'
              }
            >
              {disabled ? (
                'Logging in...'
              ) : isAuthenticated ? (
                <>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </>
              ) : (
                'Login'
              )}
            </Button>
          </div>
        </div>
      </header>
      {showSubscriptionDialog && (
        <SubscriptionDialog
          open={showSubscriptionDialog}
          onClose={() => setShowSubscriptionDialog(false)}
        />
      )}
      {showPaymentHistory && (
        <PaymentHistoryDialog
          open={showPaymentHistory}
          onClose={() => setShowPaymentHistory(false)}
        />
      )}
      {showCharityManagement && (
        <CharityManagementDialog
          open={showCharityManagement}
          onClose={() => setShowCharityManagement(false)}
        />
      )}
    </>
  );
}

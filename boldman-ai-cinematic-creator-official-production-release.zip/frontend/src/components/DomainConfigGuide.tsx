import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Globe, CheckCircle, Copy, ExternalLink, Shield, Award, Cloud } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';

export default function DomainConfigGuide() {
  const [copiedStep, setCopiedStep] = useState<number | null>(null);

  const copyToClipboard = (text: string, step: number) => {
    navigator.clipboard.writeText(text);
    setCopiedStep(step);
    toast.success('Copied to clipboard!');
    setTimeout(() => setCopiedStep(null), 2000);
  };

  const dnsRecords = [
    {
      type: 'CNAME',
      name: 'boldman.ai',
      value: 'icp1.io',
      ttl: '3600',
    },
    {
      type: 'TXT',
      name: '_canister-id.boldman.ai',
      value: 'YOUR_CANISTER_ID',
      ttl: '3600',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="border-purple-500/30 bg-gradient-to-r from-purple-600/10 to-pink-600/10 backdrop-blur-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-2xl">
            <Globe className="h-8 w-8 text-purple-400" />
            <span className="text-white">Custom Domain Configuration: boldman.ai</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-purple-200 mb-4">
            Configure your custom domain <strong className="text-white">boldman.ai</strong> to point to your BoldMan AI Cinematic Creator deployment on the Internet Computer network.
          </p>
          <div className="flex flex-wrap gap-2">
            <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-glow flex items-center gap-2">
              <Cloud className="h-4 w-4" />
              <span>Internet Computer</span>
            </div>
            <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-glow flex items-center gap-2">
              <Award className="h-4 w-4" />
              <span>Full Ownership</span>
            </div>
            <div className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-glow flex items-center gap-2">
              <Shield className="h-4 w-4" />
              <span>Secure SSL/TLS</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Ownership Notice */}
      <Alert className="border-green-500/30 bg-gradient-to-r from-green-600/10 to-emerald-600/10">
        <Award className="h-5 w-5 text-green-400" />
        <AlertDescription className="text-green-100">
          <strong>Full Commercial Ownership:</strong> You have complete ownership and intellectual property rights to the BoldMan app, including all branding assets, visual identity, and deployed canisters. This includes full commercial usage rights for the domain <strong>boldman.ai</strong>.
        </AlertDescription>
      </Alert>

      {/* DNS Configuration Steps */}
      <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
        <CardHeader>
          <CardTitle className="text-xl text-white">DNS Configuration Steps</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Step 1 */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-sm font-bold text-white">
                1
              </div>
              <h3 className="text-lg font-semibold text-white">Access Your Domain Registrar</h3>
            </div>
            <p className="text-purple-200 ml-10">
              Log in to your domain registrar (e.g., GoDaddy, Namecheap, Cloudflare) where you registered <strong>boldman.ai</strong>.
            </p>
          </div>

          {/* Step 2 */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-sm font-bold text-white">
                2
              </div>
              <h3 className="text-lg font-semibold text-white">Add DNS Records</h3>
            </div>
            <div className="ml-10 space-y-4">
              {dnsRecords.map((record, index) => (
                <div key={index} className="rounded-lg bg-black/30 p-4 border border-purple-500/20">
                  <div className="grid gap-2 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="text-purple-300">Type:</span>
                      <span className="text-white font-mono font-semibold">{record.type}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-purple-300">Name:</span>
                      <span className="text-white font-mono">{record.name}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-purple-300">Value:</span>
                      <span className="text-white font-mono">{record.value}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-purple-300">TTL:</span>
                      <span className="text-white font-mono">{record.ttl}</span>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    className="mt-3 w-full"
                    onClick={() => copyToClipboard(record.value, index)}
                  >
                    {copiedStep === index ? (
                      <>
                        <CheckCircle className="mr-2 h-4 w-4 text-green-400" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="mr-2 h-4 w-4" />
                        Copy Value
                      </>
                    )}
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Step 3 */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-sm font-bold text-white">
                3
              </div>
              <h3 className="text-lg font-semibold text-white">Wait for DNS Propagation</h3>
            </div>
            <p className="text-purple-200 ml-10">
              DNS changes can take 24-48 hours to propagate globally. You can check the status using DNS lookup tools.
            </p>
          </div>

          {/* Step 4 */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-sm font-bold text-white">
                4
              </div>
              <h3 className="text-lg font-semibold text-white">SSL/TLS Certificate</h3>
            </div>
            <p className="text-purple-200 ml-10">
              The Internet Computer will automatically provision an SSL/TLS certificate for <strong>boldman.ai</strong> once DNS is configured correctly.
            </p>
          </div>

          {/* Step 5 */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-sm font-bold text-white">
                5
              </div>
              <h3 className="text-lg font-semibold text-white">Verify Configuration</h3>
            </div>
            <p className="text-purple-200 ml-10">
              Once DNS propagates, visit <strong>https://boldman.ai</strong> to verify your deployment is accessible.
            </p>
            <div className="ml-10">
              <Button
                variant="outline"
                className="mt-2"
                onClick={() => window.open('https://boldman.ai', '_blank')}
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                Visit boldman.ai
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security & Verification */}
      <Card className="border-blue-500/30 bg-gradient-to-r from-blue-600/10 to-cyan-600/10 backdrop-blur-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl text-white">
            <Shield className="h-6 w-6 text-blue-400" />
            Security & Verification
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-purple-200">
          <div className="flex items-start gap-2">
            <CheckCircle className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
            <p>
              <strong className="text-white">Automatic SSL/TLS:</strong> Internet Computer provides automatic HTTPS encryption for your custom domain.
            </p>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
            <p>
              <strong className="text-white">Decentralized Hosting:</strong> Your application runs on the Internet Computer blockchain, ensuring high availability and security.
            </p>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle className="h-5 w-5 text-green-400 flex-shrink-0 mt-0.5" />
            <p>
              <strong className="text-white">Full Control:</strong> You maintain complete ownership and control over your domain and canister deployment.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Commercial Rights Notice */}
      <Card className="border-purple-500/30 bg-gradient-to-r from-purple-600/10 to-pink-600/10 backdrop-blur-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl text-white">
            <Award className="h-6 w-6 text-purple-400" />
            Commercial Rights & Ownership
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-purple-200">
          <p>
            <strong className="text-white">Full Commercial Ownership:</strong> You have been granted complete ownership and intellectual property rights to the BoldMan AI Cinematic Creator application.
          </p>
          <div className="space-y-2 ml-4">
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-400 flex-shrink-0 mt-0.5" />
              <span>Complete ownership of all branding assets and visual identity</span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-400 flex-shrink-0 mt-0.5" />
              <span>Full ownership of deployed Internet Computer canisters</span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-400 flex-shrink-0 mt-0.5" />
              <span>Unrestricted commercial usage and modification rights</span>
            </div>
            <div className="flex items-start gap-2">
              <CheckCircle className="h-4 w-4 text-green-400 flex-shrink-0 mt-0.5" />
              <span>Exclusive rights to operate under the <strong>boldman.ai</strong> domain</span>
            </div>
          </div>
          <p className="mt-4 text-sm text-purple-300 font-semibold">
            All content created by users on the platform belongs to them with full commercial rights.
          </p>
        </CardContent>
      </Card>

      {/* Help & Resources */}
      <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
        <CardHeader>
          <CardTitle className="text-xl text-white">Additional Resources</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Button
            variant="outline"
            className="w-full justify-start"
            onClick={() => window.open('https://internetcomputer.org/docs/current/developer-docs/web-apps/custom-domains/', '_blank')}
          >
            <ExternalLink className="mr-2 h-4 w-4" />
            Internet Computer Custom Domain Documentation
          </Button>
          <Button
            variant="outline"
            className="w-full justify-start"
            onClick={() => window.open('https://dnschecker.org/', '_blank')}
          >
            <ExternalLink className="mr-2 h-4 w-4" />
            DNS Propagation Checker
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { AlertTriangle, Shield } from 'lucide-react';

interface ContentResponsibilityModalProps {
  open: boolean;
  onAccept: () => void;
  onCancel: () => void;
}

export default function ContentResponsibilityModal({ open, onAccept, onCancel }: ContentResponsibilityModalProps) {
  const [agreed, setAgreed] = useState(false);

  const handleAccept = () => {
    if (agreed) {
      onAccept();
    }
  };

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onCancel()}>
      <DialogContent className="max-w-2xl bg-gradient-to-br from-purple-900 to-indigo-900 border-purple-500/50">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white flex items-center gap-3">
            <img 
              src="/assets/generated/responsibility-modal-illustration.dim_400x300.png" 
              alt="Content Responsibility"
              className="h-12 w-12 rounded-lg"
            />
            Content Responsibility Acknowledgment
          </DialogTitle>
          <DialogDescription className="text-purple-200 text-base">
            Please read and acknowledge the following before submitting your content
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="rounded-lg bg-amber-500/10 border border-amber-500/30 p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-6 w-6 text-amber-400 flex-shrink-0 mt-0.5" />
              <div className="space-y-2">
                <h3 className="font-semibold text-amber-200">Important Notice</h3>
                <p className="text-sm text-amber-100">
                  You are solely responsible for all content you create, upload, or generate using BoldMan AI Cinematic Creator.
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-lg bg-blue-500/10 border border-blue-500/30 p-4">
            <div className="flex items-start gap-3">
              <Shield className="h-6 w-6 text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="space-y-2">
                <h3 className="font-semibold text-blue-200">AI Content Safety Detection</h3>
                <p className="text-sm text-blue-100">
                  Our AI system automatically scans all content for safety violations. Content that violates our guidelines will be automatically blocked.
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-3 text-white">
            <h4 className="font-semibold text-purple-200">Prohibited Content Includes:</h4>
            <ul className="space-y-2 text-sm text-purple-100 pl-4">
              <li className="flex items-start gap-2">
                <span className="text-red-400 font-bold">•</span>
                <span>Child abuse or exploitation content</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 font-bold">•</span>
                <span>Animal cruelty depictions</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 font-bold">•</span>
                <span>Violence or physical harm promotion</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-red-400 font-bold">•</span>
                <span>Illegal or harmful real-life acts</span>
              </li>
            </ul>
          </div>

          <div className="rounded-lg bg-red-500/10 border border-red-500/30 p-4">
            <p className="text-sm text-red-200">
              <strong>Warning:</strong> Violations will be logged and linked to your user ID. Repeated violations may result in account suspension.
            </p>
          </div>

          <div className="flex items-start gap-3 pt-2">
            <Checkbox
              id="agree"
              checked={agreed}
              onCheckedChange={(checked) => setAgreed(checked === true)}
              className="mt-1 border-white/30 data-[state=checked]:bg-purple-600 data-[state=checked]:border-purple-600"
            />
            <Label htmlFor="agree" className="text-white text-sm cursor-pointer leading-relaxed">
              I acknowledge that I am solely responsible for my content and understand that any detected violations will lead to automatic blocking. I agree to comply with all content safety guidelines.
            </Label>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button
            onClick={onCancel}
            variant="outline"
            className="border-white/20 bg-white/10 text-white hover:bg-white/20"
          >
            Cancel
          </Button>
          <Button
            onClick={handleAccept}
            disabled={!agreed}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:opacity-50"
          >
            I Agree & Continue
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

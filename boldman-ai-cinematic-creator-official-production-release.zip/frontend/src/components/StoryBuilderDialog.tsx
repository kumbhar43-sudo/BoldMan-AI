import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, Users, Film, Save, Loader2, Sparkles } from 'lucide-react';
import { useCreateMultiCharacterStory, useUpdateStory, useIsPromptAssistantEnabled } from '../hooks/useQueries';
import type { Story, Character, Scene } from '../backend';
import { toast } from 'sonner';
import CharacterManager from './CharacterManager';
import SceneEditor from './SceneEditor';
import StoryPreview from './StoryPreview';
import ContentResponsibilityModal from './ContentResponsibilityModal';
import AiPromptAssistant from './AiPromptAssistant';

interface StoryBuilderDialogProps {
  onClose: () => void;
  story?: Story | null;
}

export default function StoryBuilderDialog({ onClose, story }: StoryBuilderDialogProps) {
  const [title, setTitle] = useState(story?.title || '');
  const [description, setDescription] = useState(story?.description || '');
  const [characters, setCharacters] = useState<Character[]>(story?.characters || []);
  const [scenes, setScenes] = useState<Scene[]>(story?.scenes || []);
  const [activeTab, setActiveTab] = useState('info');
  const [showResponsibilityModal, setShowResponsibilityModal] = useState(false);
  const [showAiAssistant, setShowAiAssistant] = useState(false);

  const createStory = useCreateMultiCharacterStory();
  const updateStory = useUpdateStory();
  const { data: isAiEnabled } = useIsPromptAssistantEnabled();

  const isEditing = !!story;

  const handleSave = async () => {
    if (!title.trim()) {
      toast.error('Please enter a title');
      return;
    }

    if (characters.length === 0) {
      toast.error('Please add at least one character');
      return;
    }

    try {
      if (isEditing) {
        await updateStory.mutateAsync({
          storyId: story.storyId,
          title: title.trim(),
          description: description.trim(),
          characters,
          scenes,
        });
        toast.success('Story updated!');
      } else {
        await createStory.mutateAsync({
          title: title.trim(),
          description: description.trim(),
          characters,
          scenes,
        });
        toast.success('Story created!');
      }
      onClose();
    } catch (error: any) {
      if (error?.message?.includes('violates safety guidelines')) {
        toast.error('Content blocked: Violates safety guidelines', {
          description: 'Your content was flagged by our AI safety system. Please review our content policy.',
          duration: 5000,
        });
      } else {
        toast.error('Error saving story');
      }
      console.error(error);
    }
  };

  const handleSaveWithAcknowledgment = () => {
    setShowResponsibilityModal(true);
  };

  const handleResponsibilityAccept = () => {
    setShowResponsibilityModal(false);
    handleSave();
  };

  const handleAiSuggestionApply = (suggestion: string) => {
    if (activeTab === 'info') {
      setDescription(prev => prev ? `${prev}\n\n${suggestion}` : suggestion);
    }
  };

  const isPending = createStory.isPending || updateStory.isPending;

  return (
    <>
      <Dialog open={true} onOpenChange={onClose}>
        <DialogContent className="max-w-6xl bg-gradient-to-br from-purple-900 to-indigo-900 border-purple-500/50 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-center justify-between">
              <DialogTitle className="text-2xl text-white flex items-center gap-2">
                <BookOpen className="h-6 w-6" />
                {isEditing ? 'Edit Story' : 'Create New Story'}
              </DialogTitle>
              {isAiEnabled && activeTab === 'info' && (
                <Button
                  onClick={() => setShowAiAssistant(!showAiAssistant)}
                  variant="outline"
                  size="sm"
                  className="border-purple-500/30 bg-white/10 text-white hover:bg-white/20"
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  {showAiAssistant ? 'Hide' : 'Show'} AI Assistant
                </Button>
              )}
            </div>
          </DialogHeader>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList className="bg-white/10 border border-white/20 w-full">
              <TabsTrigger value="info" className="flex-1 data-[state=active]:bg-purple-600">
                <BookOpen className="mr-2 h-4 w-4" />
                Info
              </TabsTrigger>
              <TabsTrigger value="characters" className="flex-1 data-[state=active]:bg-purple-600">
                <Users className="mr-2 h-4 w-4" />
                Characters ({characters.length})
              </TabsTrigger>
              <TabsTrigger value="scenes" className="flex-1 data-[state=active]:bg-purple-600">
                <Film className="mr-2 h-4 w-4" />
                Scenes ({scenes.length})
              </TabsTrigger>
              <TabsTrigger value="preview" className="flex-1 data-[state=active]:bg-purple-600">
                Preview
              </TabsTrigger>
            </TabsList>

            <TabsContent value="info" className="space-y-4 mt-6">
              <div className="space-y-2">
                <Label htmlFor="story-title" className="text-white">Title *</Label>
                <Input
                  id="story-title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Story title"
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="story-description" className="text-white">Description</Label>
                <Textarea
                  id="story-description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Brief story description"
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50 min-h-32"
                />
              </div>

              <div className="rounded-lg bg-blue-500/10 border border-blue-500/30 p-4">
                <p className="text-sm text-blue-200">
                  <strong>Tip:</strong> Create your characters first, then add their dialogues in scenes.
                </p>
              </div>

              {isAiEnabled && showAiAssistant && (
                <AiPromptAssistant
                  context={`Title: ${title}\n\nDescription: ${description}`}
                  onSuggestionApply={handleAiSuggestionApply}
                  placeholder="Ask AI to help develop your story..."
                  mode="story"
                />
              )}
            </TabsContent>

            <TabsContent value="characters" className="mt-6">
              <CharacterManager
                characters={characters}
                onCharactersChange={setCharacters}
              />
            </TabsContent>

            <TabsContent value="scenes" className="mt-6">
              <SceneEditor
                scenes={scenes}
                characters={characters}
                onScenesChange={setScenes}
              />
            </TabsContent>

            <TabsContent value="preview" className="mt-6">
              <StoryPreview
                title={title}
                description={description}
                characters={characters}
                scenes={scenes}
              />
            </TabsContent>
          </Tabs>

          <div className="flex gap-2 mt-6 pt-6 border-t border-white/20">
            <Button
              onClick={handleSaveWithAcknowledgment}
              disabled={isPending}
              className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  {isEditing ? 'Update' : 'Save Story'}
                </>
              )}
            </Button>
            <Button
              onClick={onClose}
              variant="outline"
              className="border-white/20 bg-white/10 text-white hover:bg-white/20"
            >
              Cancel
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <ContentResponsibilityModal
        open={showResponsibilityModal}
        onAccept={handleResponsibilityAccept}
        onCancel={() => setShowResponsibilityModal(false)}
      />
    </>
  );
}

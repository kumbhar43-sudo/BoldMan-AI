import { Card, CardContent } from '@/components/ui/card';
import { Clock, Users, Zap } from 'lucide-react';
import { useGetRenderQueueStatus, useGetFreemiumLimits } from '../hooks/useQueries';

export default function RenderQueueStatus() {
  const { data: queueStatus } = useGetRenderQueueStatus();
  const { data: limits } = useGetFreemiumLimits();

  if (!queueStatus || Number(queueStatus.tasksInQueue) === 0) {
    return null;
  }

  const isFreeUser = limits?.subscriptionTier === 'free';
  const estimatedMinutes = Math.ceil(Number(queueStatus.estimatedWaitTime) / 60);

  return (
    <Card className="border-blue-500/30 bg-blue-500/10 backdrop-blur-lg mb-6">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-blue-500/20">
              <Clock className="h-5 w-5 text-blue-400 animate-pulse" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white">Render Queue Status</h4>
              <p className="text-xs text-blue-200">
                {Number(queueStatus.tasksInQueue)} task{Number(queueStatus.tasksInQueue) !== 1 ? 's' : ''} in queue
                {estimatedMinutes > 0 && ` • ~${estimatedMinutes} min wait`}
              </p>
            </div>
          </div>
          {isFreeUser && (
            <div className="flex items-center gap-2 text-xs text-blue-300">
              <Users className="h-4 w-4" />
              <span>Free users have delayed processing</span>
            </div>
          )}
        </div>
        {isFreeUser && (
          <div className="mt-3 p-2 rounded bg-purple-500/10 border border-purple-500/30">
            <p className="text-xs text-purple-200 flex items-center gap-2">
              <Zap className="h-3 w-3 text-purple-400" />
              Upgrade to Pro or Full plan for priority rendering with no delays
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}


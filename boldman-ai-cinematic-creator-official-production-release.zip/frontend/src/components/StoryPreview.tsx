import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { BookOpen, Users, Film, MessageSquare } from 'lucide-react';
import type { Character, Scene } from '../backend';

interface StoryPreviewProps {
  title: string;
  description: string;
  characters: Character[];
  scenes: Scene[];
}

export default function StoryPreview({ title, description, characters, scenes }: StoryPreviewProps) {
  const getCharacterName = (id: bigint) => {
    return characters.find(c => c.id === id)?.name || 'अज्ञात';
  };

  if (!title && characters.length === 0 && scenes.length === 0) {
    return (
      <div className="text-center py-16">
        <BookOpen className="h-16 w-16 text-purple-300 mx-auto mb-4" />
        <p className="text-purple-200">
          कहानी का प्रीव्यू देखने के लिए जानकारी, कैरेक्टर और सीन जोड़ें
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="border-purple-500/30 bg-white/5">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            {title || 'शीर्षक रहित कहानी'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {description && (
            <p className="text-purple-200">{description}</p>
          )}
          <div className="flex gap-3 mt-4">
            <Badge variant="secondary" className="flex items-center gap-1">
              <Users className="h-3 w-3" />
              {characters.length} कैरेक्टर
            </Badge>
            <Badge variant="secondary" className="flex items-center gap-1">
              <Film className="h-3 w-3" />
              {scenes.length} सीन
            </Badge>
          </div>
        </CardContent>
      </Card>

      {characters.length > 0 && (
        <Card className="border-purple-500/30 bg-white/5">
          <CardHeader>
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <Users className="h-5 w-5" />
              कैरेक्टर
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 md:grid-cols-2">
              {characters.map((char) => (
                <div key={char.id.toString()} className="flex items-center gap-3 p-3 rounded-lg bg-white/5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex-shrink-0">
                    <span className="text-white font-semibold">{char.name[0]}</span>
                  </div>
                  <div>
                    <p className="text-white font-medium">{char.name}</p>
                    <p className="text-xs text-purple-300">
                      {char.voice.gender === 'male' ? 'पुरुष' : 'महिला'} • {char.language}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {scenes.length > 0 && (
        <Card className="border-purple-500/30 bg-white/5">
          <CardHeader>
            <CardTitle className="text-white text-lg flex items-center gap-2">
              <Film className="h-5 w-5" />
              सीन ({scenes.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-4">
                {scenes.map((scene, index) => (
                  <Card key={scene.id.toString()} className="border-purple-500/30 bg-white/10">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3 mb-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex-shrink-0">
                          <span className="text-white text-sm font-semibold">{index + 1}</span>
                        </div>
                        <div className="flex-1">
                          <h4 className="text-white font-semibold">{scene.title}</h4>
                          {scene.description && (
                            <p className="text-sm text-purple-200 mt-1">{scene.description}</p>
                          )}
                          <div className="flex gap-2 mt-2 text-xs text-purple-300">
                            <span>{scene.background}</span>
                            <span>•</span>
                            <span>{scene.music}</span>
                          </div>
                        </div>
                      </div>

                      {scene.dialogues.length > 0 && (
                        <div className="space-y-2 mt-3 pt-3 border-t border-white/10">
                          {scene.dialogues.map((dialogue, dIndex) => (
                            <div key={dIndex} className="flex gap-2">
                              <MessageSquare className="h-4 w-4 text-purple-400 flex-shrink-0 mt-0.5" />
                              <div className="flex-1">
                                <p className="text-sm text-purple-300 font-medium">
                                  {getCharacterName(dialogue.characterId)}
                                  <span className="text-purple-400 ml-2">({dialogue.emotion})</span>
                                </p>
                                <p className="text-sm text-white mt-1">{dialogue.dialogueText}</p>
                                {dialogue.actions && (
                                  <p className="text-xs text-purple-400 italic mt-1">
                                    [{dialogue.actions}]
                                  </p>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

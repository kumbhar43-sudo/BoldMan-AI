import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Check, Heart, Loader2, Sparkles, Info, X, Clock, Zap } from 'lucide-react';
import { useCheckout, useListStripePrices, useGetCharitySettings } from '../hooks/useQueries';
import { toast } from 'sonner';

interface SubscriptionDialogProps {
  open: boolean;
  onClose: () => void;
}

export default function SubscriptionDialog({ open, onClose }: SubscriptionDialogProps) {
  const { data: prices, isLoading: pricesLoading } = useListStripePrices();
  const { data: charitySettings } = useGetCharitySettings();
  const checkout = useCheckout();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  const handleSubscribe = async (priceId: string) => {
    setSelectedPlan(priceId);
    try {
      const result = await checkout.mutateAsync(priceId);
      window.location.href = result.checkoutUrl;
    } catch (error) {
      toast.error('Checkout failed. Please try again.');
      console.error(error);
      setSelectedPlan(null);
    }
  };

  const formatPrice = (amount: bigint) => {
    return `$${(Number(amount) / 100).toFixed(2)}`;
  };

  const calculateCharityAmount = (amount: bigint) => {
    if (!charitySettings) return 0;
    return (Number(amount) * Number(charitySettings.charityPercentage)) / 10000;
  };

  const plans = [
    {
      id: 'free_trial',
      name: 'Free Trial',
      description: 'Limited features for testing',
      isFree: true,
      features: [
        '10 AI prompts per month',
        '30-second max video duration',
        'Watermarked outputs',
        'Render queue delays',
        '2 video explainers',
      ],
      limitations: [
        'Limited AI prompts',
        'Short video duration',
        'Watermarked videos',
        'Delayed processing',
      ],
    },
    {
      id: 'basic_subscription',
      name: 'Basic Plan',
      description: 'Standard video creation',
      features: [
        '50 AI prompts per month',
        '2-hour max video duration',
        'No watermarks',
        'Standard rendering',
        '10 video explainers',
        'HD quality export',
      ],
    },
    {
      id: 'pro_subscription',
      name: 'Pro Plan',
      description: 'Advanced features',
      popular: true,
      features: [
        '200 AI prompts per month',
        '5-hour max video duration',
        'No watermarks',
        'Priority rendering',
        '50 video explainers',
        'Multi-character stories',
        'Voice cloning',
        'HD quality export',
      ],
    },
    {
      id: 'full_subscription',
      name: 'Full Plan',
      description: 'Complete access',
      features: [
        'Unlimited AI prompts',
        'Unlimited video duration',
        'No watermarks',
        'Priority rendering',
        'Unlimited explainers',
        'Multi-character stories',
        'Voice cloning',
        '4K quality export',
        'Priority support',
      ],
    },
  ];

  const getPriceForPlan = (planId: string) => {
    return prices?.find((p) => p.priceId === planId);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-purple-950 via-indigo-950 to-blue-950 border-purple-500/30">
        <DialogHeader>
          <DialogTitle className="text-3xl font-bold text-white flex items-center gap-2">
            <Sparkles className="h-8 w-8 text-purple-400" />
            Subscription Plans
          </DialogTitle>
          <DialogDescription className="text-purple-200 text-lg">
            Choose the right plan for your needs - Compare features and limits
          </DialogDescription>
        </DialogHeader>

        {charitySettings && (
          <div className="mb-6 rounded-lg bg-gradient-to-r from-pink-600/20 to-purple-600/20 p-4 border border-pink-500/30">
            <div className="flex items-start gap-3">
              <Heart className="h-6 w-6 text-pink-400 fill-pink-400 flex-shrink-0 mt-1" />
              <div className="flex-1">
                <p className="text-white font-semibold mb-1">
                  Automated Charity Contribution: {Number(charitySettings.charityPercentage)}%
                </p>
                <p className="text-sm text-purple-200 mb-2">
                  {Number(charitySettings.charityPercentage)}% of each purchase is automatically split and transferred to multiple charity accounts
                </p>
                <div className="flex items-center gap-2 text-xs text-purple-300">
                  <Info className="h-4 w-4" />
                  <span>Payments are automatically distributed to owner and charity accounts via Stripe Connect</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {pricesLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {plans.map((plan) => {
              const price = getPriceForPlan(plan.id);
              const isLoading = selectedPlan === plan.id && checkout.isPending;
              const charityAmount = price ? calculateCharityAmount(price.unitAmount) : 0;

              return (
                <Card
                  key={plan.id}
                  className={`border-purple-500/30 bg-white/5 backdrop-blur-lg hover:bg-white/10 transition-all ${
                    plan.popular ? 'ring-2 ring-purple-500' : ''
                  }`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <CardTitle className="text-lg text-white">
                        {plan.name}
                      </CardTitle>
                      {plan.popular && (
                        <Badge className="bg-gradient-to-r from-purple-600 to-pink-600">
                          Popular
                        </Badge>
                      )}
                      {plan.isFree && (
                        <Badge variant="outline" className="border-purple-500 text-purple-300">
                          Free
                        </Badge>
                      )}
                    </div>
                    <div className="mt-4">
                      {price ? (
                        <>
                          <div className="text-2xl font-bold text-white">
                            {formatPrice(price.unitAmount)}
                          </div>
                          {charityAmount > 0 && (
                            <div className="mt-2 text-sm text-pink-400 flex items-center gap-1">
                              <Heart className="h-3 w-3 fill-pink-400" />
                              ${charityAmount.toFixed(2)} to charity
                            </div>
                          )}
                        </>
                      ) : plan.isFree ? (
                        <div className="text-2xl font-bold text-white">Free</div>
                      ) : (
                        <div className="text-sm text-purple-400">Loading price...</div>
                      )}
                    </div>
                    <p className="text-sm text-purple-200 mt-2">{plan.description}</p>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 mb-6">
                      {plan.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-sm text-purple-100">
                          <Check className="h-4 w-4 text-green-400 mt-0.5 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                      {plan.limitations && plan.limitations.map((limitation, idx) => (
                        <li key={`limit-${idx}`} className="flex items-start gap-2 text-sm text-amber-300">
                          <X className="h-4 w-4 text-amber-400 mt-0.5 flex-shrink-0" />
                          <span>{limitation}</span>
                        </li>
                      ))}
                    </ul>
                    {plan.isFree ? (
                      <Button
                        disabled
                        className="w-full bg-white/10 text-purple-300"
                      >
                        Current Plan
                      </Button>
                    ) : (
                      <Button
                        onClick={() => handleSubscribe(plan.id)}
                        disabled={!price || isLoading}
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                      >
                        {isLoading ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          <>
                            {plan.id === 'pro_subscription' || plan.id === 'full_subscription' ? (
                              <Zap className="mr-2 h-4 w-4" />
                            ) : (
                              <Clock className="mr-2 h-4 w-4" />
                            )}
                            Subscribe
                          </>
                        )}
                      </Button>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        <div className="mt-6 space-y-2">
          <div className="text-center text-sm text-purple-300">
            <p>Secure payment powered by Stripe</p>
            <p className="mt-1">Full commercial rights included</p>
          </div>
          <div className="rounded-lg bg-white/5 p-3 border border-purple-500/20">
            <p className="text-xs text-purple-300 text-center">
              Tax-compliant invoices with TDS and GST breakdown will be generated automatically for all transactions
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}


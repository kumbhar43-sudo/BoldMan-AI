import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useSaveCallerUserProfile } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import type { UserProfile } from '../backend';
import { toast } from 'sonner';

export default function ProfileSetupDialog() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const { identity } = useInternetIdentity();
  const saveProfile = useSaveCallerUserProfile();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast.error('Please enter your name');
      return;
    }

    if (!identity) {
      toast.error('Identity not available');
      return;
    }

    const profile: UserProfile = {
      id: identity.getPrincipal(),
      name: name.trim(),
      email: email.trim(),
      preferences: {
        language: 'en',
        voice: 'english-american',
        quality: 'hd',
      },
      createdAt: BigInt(Date.now() * 1000000),
      lastLogin: BigInt(Date.now() * 1000000),
    };

    try {
      await saveProfile.mutateAsync(profile);
      toast.success('Profile created successfully!');
    } catch (error: any) {
      if (error?.message?.includes('violates safety guidelines')) {
        toast.error('Content blocked: Violates safety guidelines', {
          description: 'Your profile information was flagged by our AI safety system.',
          duration: 5000,
        });
      } else {
        toast.error('Error creating profile');
      }
      console.error(error);
    }
  };

  return (
    <Dialog open={true}>
      <DialogContent className="bg-gradient-to-br from-purple-900 to-indigo-900 border-purple-500/50">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white">Set Up Your Profile</DialogTitle>
          <DialogDescription className="text-purple-200">
            Please enter your information to get started
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="name" className="text-white">Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
              className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email" className="text-white">Email (Optional)</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Your email"
              className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
            />
          </div>
          <Button
            type="submit"
            disabled={saveProfile.isPending}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            {saveProfile.isPending ? 'Saving...' : 'Create Profile'}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}

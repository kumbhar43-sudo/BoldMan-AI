import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, BookOpen } from 'lucide-react';
import { useGetAllStoriesByUser } from '../hooks/useQueries';
import StoryBuilderDialog from './StoryBuilderDialog';
import StoryCard from './StoryCard';

export default function StoryBuilder() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingStory, setEditingStory] = useState<any>(null);
  const { data: stories, isLoading } = useGetAllStoriesByUser();

  const handleEdit = (story: any) => {
    setEditingStory(story);
    setShowDialog(true);
  };

  const handleCloseDialog = () => {
    setShowDialog(false);
    setEditingStory(null);
  };

  if (isLoading) {
    return (
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
            <CardContent className="p-6">
              <div className="h-32 bg-white/10 rounded-lg mb-4 animate-pulse" />
              <div className="h-6 bg-white/10 rounded mb-2 animate-pulse" />
              <div className="h-4 bg-white/10 rounded w-2/3 animate-pulse" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!stories || stories.length === 0) {
    return (
      <>
        <div className="text-center py-16">
          <div className="mb-4 flex justify-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-white/10">
              <BookOpen className="h-10 w-10 text-purple-300" />
            </div>
          </div>
          <h3 className="text-2xl font-semibold text-white mb-2">
            अपनी कहानियाँ बनाएं
          </h3>
          <p className="text-purple-200 mb-6">
            मल्टी-कैरेक्टर स्टोरी-बेस्ड वीडियो बनाने के लिए शुरू करें
          </p>
          <Button
            onClick={() => setShowDialog(true)}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            <Plus className="mr-2 h-5 w-5" />
            नई कहानी बनाएं
          </Button>
        </div>
        {showDialog && <StoryBuilderDialog onClose={handleCloseDialog} story={editingStory} />}
      </>
    );
  }

  return (
    <>
      <div className="mb-6 flex justify-end">
        <Button
          onClick={() => setShowDialog(true)}
          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
        >
          <Plus className="mr-2 h-5 w-5" />
          नई कहानी बनाएं
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {stories.map((story) => (
          <StoryCard key={story.storyId.toString()} story={story} onEdit={handleEdit} />
        ))}
      </div>

      {showDialog && <StoryBuilderDialog onClose={handleCloseDialog} story={editingStory} />}
    </>
  );
}

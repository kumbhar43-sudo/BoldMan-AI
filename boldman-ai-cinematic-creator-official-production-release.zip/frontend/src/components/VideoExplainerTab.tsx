import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Mic, Languages, Play } from 'lucide-react';
import { useGetAllExplainersByUser, useGetVideosByUser } from '../hooks/useQueries';
import CreateExplainerDialog from './CreateExplainerDialog';

export default function VideoExplainerTab() {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedVideoId, setSelectedVideoId] = useState<bigint | null>(null);
  const { data: explainers, isLoading: explainersLoading } = useGetAllExplainersByUser();
  const { data: videos } = useGetVideosByUser();

  if (explainersLoading) {
    return (
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
            <CardContent className="p-6">
              <div className="h-32 bg-white/10 rounded-lg mb-4 animate-pulse" />
              <div className="h-6 bg-white/10 rounded mb-2 animate-pulse" />
              <div className="h-4 bg-white/10 rounded w-2/3 animate-pulse" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <Card className="border-purple-500/30 bg-gradient-to-br from-purple-600/20 to-pink-600/20 backdrop-blur-lg">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="space-y-2">
              <CardTitle className="text-2xl text-white flex items-center gap-2">
                <img 
                  src="/assets/generated/video-explainer-dashboard.dim_800x600.png" 
                  alt="Video Explainer" 
                  className="h-8 w-8 object-contain"
                />
                Video Explainer
              </CardTitle>
              <p className="text-purple-200 text-sm">
                Create multi-language explanations for your videos and clone your voice
              </p>
            </div>
            <Button
              onClick={() => setShowCreateDialog(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <Plus className="mr-2 h-4 w-4" />
              New Explainer
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Features Overview */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-purple-600/20">
                <Languages className="h-6 w-6 text-purple-300" />
              </div>
              <h3 className="font-semibold text-white">Multi-Language Support</h3>
            </div>
            <p className="text-sm text-purple-200">
              Create explanations in English, Hindi, and 15+ languages
            </p>
          </CardContent>
        </Card>

        <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-pink-600/20">
                <Mic className="h-6 w-6 text-pink-300" />
              </div>
              <h3 className="font-semibold text-white">Voice Cloning</h3>
            </div>
            <p className="text-sm text-purple-200">
              Record your voice and clone it with AI
            </p>
          </CardContent>
        </Card>

        <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2 rounded-lg bg-purple-600/20">
                <Play className="h-6 w-6 text-purple-300" />
              </div>
              <h3 className="font-semibold text-white">AI Voice Options</h3>
            </div>
            <p className="text-sm text-purple-200">
              Choose from male, female, and neutral voices
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Explainers List */}
      {!explainers || explainers.length === 0 ? (
        <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
          <CardContent className="p-12 text-center">
            <div className="mb-4 flex justify-center">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-white/10">
                <Mic className="h-10 w-10 text-purple-300" />
              </div>
            </div>
            <h3 className="text-2xl font-semibold text-white mb-2">
              No Explainers Yet
            </h3>
            <p className="text-purple-200 mb-6">
              Click "New Explainer" to create your first video explainer
            </p>
            <Button
              onClick={() => setShowCreateDialog(true)}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              <Plus className="mr-2 h-4 w-4" />
              Get Started
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="text-center text-purple-200 py-12">
          <p>Video explainer feature coming soon!</p>
          <p className="text-sm mt-2">Backend implementation in progress</p>
        </div>
      )}

      {showCreateDialog && (
        <CreateExplainerDialog
          onClose={() => {
            setShowCreateDialog(false);
            setSelectedVideoId(null);
          }}
          preselectedVideoId={selectedVideoId}
        />
      )}
    </div>
  );
}


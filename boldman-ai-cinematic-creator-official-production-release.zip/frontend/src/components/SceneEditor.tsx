import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Film, MessageSquare, Edit } from 'lucide-react';
import type { Scene, Character, Dialogue } from '../backend';
import { Badge } from '@/components/ui/badge';

interface SceneEditorProps {
  scenes: Scene[];
  characters: Character[];
  onScenesChange: (scenes: Scene[]) => void;
}

export default function SceneEditor({ scenes, characters, onScenesChange }: SceneEditorProps) {
  const [showForm, setShowForm] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [background, setBackground] = useState('outdoor');
  const [music, setMusic] = useState('cinematic');
  const [dialogues, setDialogues] = useState<Dialogue[]>([]);

  const handleAddScene = () => {
    if (!title.trim()) return;

    const newScene: Scene = {
      id: BigInt(Date.now()),
      title: title.trim(),
      description: description.trim(),
      dialogues,
      characters: dialogues.map(d => d.characterId),
      music,
      background,
      createdAt: BigInt(Date.now() * 1000000),
      lastModified: BigInt(Date.now() * 1000000),
      videoFile: undefined,
      previewFile: undefined,
    };

    if (editingIndex !== null) {
      const updated = [...scenes];
      updated[editingIndex] = newScene;
      onScenesChange(updated);
      setEditingIndex(null);
    } else {
      onScenesChange([...scenes, newScene]);
    }

    resetForm();
  };

  const handleEdit = (index: number) => {
    const scene = scenes[index];
    setTitle(scene.title);
    setDescription(scene.description);
    setBackground(scene.background);
    setMusic(scene.music);
    setDialogues(scene.dialogues);
    setEditingIndex(index);
    setShowForm(true);
  };

  const handleDelete = (index: number) => {
    onScenesChange(scenes.filter((_, i) => i !== index));
  };

  const handleAddDialogue = () => {
    if (characters.length === 0) return;

    const newDialogue: Dialogue = {
      characterId: characters[0].id,
      dialogueText: '',
      emotion: 'neutral',
      actions: '',
      voiceOverFile: undefined,
      language: characters[0].language,
      accent: characters[0].accent,
    };

    setDialogues([...dialogues, newDialogue]);
  };

  const handleUpdateDialogue = (index: number, field: keyof Dialogue, value: any) => {
    const updated = [...dialogues];
    updated[index] = { ...updated[index], [field]: value };
    setDialogues(updated);
  };

  const handleDeleteDialogue = (index: number) => {
    setDialogues(dialogues.filter((_, i) => i !== index));
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setBackground('outdoor');
    setMusic('cinematic');
    setDialogues([]);
    setShowForm(false);
    setEditingIndex(null);
  };

  const getCharacterName = (id: bigint) => {
    return characters.find(c => c.id === id)?.name || 'अज्ञात';
  };

  if (characters.length === 0) {
    return (
      <div className="text-center py-8 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
        <p className="text-yellow-200">
          सीन बनाने से पहले कृपया कैरेक्टर जोड़ें
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {scenes.length > 0 && (
        <div className="space-y-3">
          {scenes.map((scene, index) => (
            <Card key={scene.id.toString()} className="border-purple-500/30 bg-white/5">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex-shrink-0">
                    <Film className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-white font-semibold">सीन {index + 1}: {scene.title}</h4>
                      <Badge variant="secondary" className="text-xs">
                        {scene.dialogues.length} डायलॉग
                      </Badge>
                    </div>
                    {scene.description && (
                      <p className="text-sm text-purple-200 mb-2">{scene.description}</p>
                    )}
                    <div className="flex gap-2 text-xs text-purple-300">
                      <span>पृष्ठभूमि: {scene.background}</span>
                      <span>•</span>
                      <span>संगीत: {scene.music}</span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEdit(index)}
                      className="text-white hover:bg-white/20 h-8 w-8 p-0"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(index)}
                      className="text-red-400 hover:bg-red-500/20 h-8 w-8 p-0"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {!showForm ? (
        <Button
          onClick={() => setShowForm(true)}
          variant="outline"
          className="w-full border-white/20 bg-white/10 text-white hover:bg-white/20"
        >
          <Plus className="mr-2 h-4 w-4" />
          नया सीन जोड़ें
        </Button>
      ) : (
        <Card className="border-purple-500/30 bg-white/5">
          <CardContent className="p-6 space-y-4">
            <h4 className="text-white font-semibold">
              {editingIndex !== null ? 'सीन संपादित करें' : 'नया सीन'}
            </h4>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label className="text-white">शीर्षक *</Label>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="सीन का शीर्षक"
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white">पृष्ठभूमि</Label>
                <Select value={background} onValueChange={setBackground}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="outdoor">बाहरी</SelectItem>
                    <SelectItem value="indoor">आंतरिक</SelectItem>
                    <SelectItem value="nature">प्रकृति</SelectItem>
                    <SelectItem value="city">शहर</SelectItem>
                    <SelectItem value="fantasy">काल्पनिक</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label className="text-white">विवरण</Label>
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="सीन का विवरण"
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50 min-h-20"
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label className="text-white">पृष्ठभूमि संगीत</Label>
                <Select value={music} onValueChange={setMusic}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cinematic">सिनेमाई</SelectItem>
                    <SelectItem value="dramatic">नाटकीय</SelectItem>
                    <SelectItem value="happy">खुशी</SelectItem>
                    <SelectItem value="sad">उदास</SelectItem>
                    <SelectItem value="suspense">रहस्य</SelectItem>
                    <SelectItem value="action">एक्शन</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-3 pt-4 border-t border-white/20">
              <div className="flex items-center justify-between">
                <Label className="text-white">डायलॉग</Label>
                <Button
                  size="sm"
                  onClick={handleAddDialogue}
                  variant="outline"
                  className="border-white/20 bg-white/10 text-white hover:bg-white/20"
                >
                  <Plus className="mr-1 h-3 w-3" />
                  डायलॉग जोड़ें
                </Button>
              </div>

              {dialogues.map((dialogue, index) => (
                <Card key={index} className="border-purple-500/30 bg-white/10">
                  <CardContent className="p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MessageSquare className="h-4 w-4 text-purple-300" />
                        <span className="text-sm text-white font-medium">
                          डायलॉग {index + 1}
                        </span>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDeleteDialogue(index)}
                        className="text-red-400 hover:bg-red-500/20 h-7 w-7 p-0"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>

                    <div className="grid gap-3 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label className="text-white text-xs">कैरेक्टर</Label>
                        <Select
                          value={dialogue.characterId.toString()}
                          onValueChange={(value) => handleUpdateDialogue(index, 'characterId', BigInt(value))}
                        >
                          <SelectTrigger className="bg-white/10 border-white/20 text-white text-sm">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {characters.map((char) => (
                              <SelectItem key={char.id.toString()} value={char.id.toString()}>
                                {char.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label className="text-white text-xs">भावना</Label>
                        <Select
                          value={dialogue.emotion}
                          onValueChange={(value) => handleUpdateDialogue(index, 'emotion', value)}
                        >
                          <SelectTrigger className="bg-white/10 border-white/20 text-white text-sm">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="neutral">सामान्य</SelectItem>
                            <SelectItem value="happy">खुश</SelectItem>
                            <SelectItem value="sad">उदास</SelectItem>
                            <SelectItem value="angry">गुस्सा</SelectItem>
                            <SelectItem value="surprised">आश्चर्य</SelectItem>
                            <SelectItem value="fearful">डर</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label className="text-white text-xs">डायलॉग टेक्स्ट *</Label>
                        <Textarea
                          value={dialogue.dialogueText}
                          onChange={(e) => handleUpdateDialogue(index, 'dialogueText', e.target.value)}
                          placeholder="कैरेक्टर का डायलॉग..."
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50 min-h-20 text-sm"
                        />
                      </div>

                      <div className="space-y-2 md:col-span-2">
                        <Label className="text-white text-xs">एक्शन/निर्देश</Label>
                        <Input
                          value={dialogue.actions}
                          onChange={(e) => handleUpdateDialogue(index, 'actions', e.target.value)}
                          placeholder="जैसे: चलता है, मुस्कुराता है..."
                          className="bg-white/10 border-white/20 text-white placeholder:text-white/50 text-sm"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}

              {dialogues.length === 0 && (
                <div className="text-center py-4 text-purple-300 text-sm">
                  इस सीन में अभी तक कोई डायलॉग नहीं है
                </div>
              )}
            </div>

            <div className="flex gap-2 pt-4 border-t border-white/20">
              <Button
                onClick={handleAddScene}
                disabled={!title.trim() || dialogues.length === 0}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                {editingIndex !== null ? 'अपडेट करें' : 'सीन जोड़ें'}
              </Button>
              <Button
                onClick={resetForm}
                variant="outline"
                className="border-white/20 bg-white/10 text-white hover:bg-white/20"
              >
                रद्द करें
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

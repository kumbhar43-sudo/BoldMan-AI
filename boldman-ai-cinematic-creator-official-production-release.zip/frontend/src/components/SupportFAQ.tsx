import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { HelpCircle } from 'lucide-react';

export default function SupportFAQ() {
  const faqs = [
    {
      question: 'What are the differences between subscription plans?',
      answer: 'Free Trial: 10 AI prompts/month, 30-second videos, watermarked outputs, delayed rendering. Basic: 50 prompts, 2-hour videos, no watermarks. Pro: 200 prompts, 5-hour videos, multi-character stories, voice cloning. Full: Unlimited prompts and videos, 4K rendering, priority support.',
    },
    {
      question: 'How does the render queue work?',
      answer: 'Free users experience delayed processing as their render tasks are queued with lower priority. Subscribers (Basic, Pro, Full) get priority processing with minimal to no wait times.',
    },
    {
      question: 'What happens when I reach my free plan limits?',
      answer: 'When you reach your monthly limits for AI prompts, video duration, or explainers, you\'ll need to upgrade to a paid plan to continue creating content. Your existing content remains accessible.',
    },
    {
      question: 'How does the charity contribution work?',
      answer: 'A percentage of each subscription payment is automatically split and transferred to multiple charity accounts via Stripe Connect. You\'ll see the breakdown in your payment confirmation and invoices.',
    },
    {
      question: 'Can I upgrade or downgrade my plan?',
      answer: 'Yes, you can upgrade your plan at any time. Contact support for downgrades. Changes take effect at the next billing cycle.',
    },
    {
      question: 'What are watermarked outputs?',
      answer: 'Free trial videos include a BoldMan watermark overlay. Upgrading to any paid plan removes watermarks from all new videos.',
    },
    {
      question: 'How do I get priority rendering?',
      answer: 'Subscribe to Pro or Full plan to get priority rendering with no queue delays. Your render tasks will be processed immediately.',
    },
    {
      question: 'What happens to my content if I cancel?',
      answer: 'Your content remains accessible, but you\'ll revert to free plan limits. You can still view and download previously created videos.',
    },
  ];

  return (
    <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-white">
          <HelpCircle className="h-5 w-5 text-purple-400" />
          Frequently Asked Questions
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`} className="border-purple-500/20">
              <AccordionTrigger className="text-white hover:text-purple-300">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-purple-200">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
}


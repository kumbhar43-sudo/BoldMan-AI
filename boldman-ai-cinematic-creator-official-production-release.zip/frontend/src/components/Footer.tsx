import { Heart, Sparkles, Shield, Award, Monitor, Globe, Cloud } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-black/30 backdrop-blur-xl">
      <div className="container mx-auto px-4 py-8">
        <div className="grid gap-8 md:grid-cols-3">
          {/* Brand Section */}
          <div className="flex flex-col items-center gap-3 md:items-start">
            <div className="flex items-center gap-2">
              <img 
                src="/assets/generated/footer-logo-transparent.dim_150x50.png" 
                alt="BoldMan" 
                className="h-10 w-auto object-contain"
              />
              <Sparkles className="h-5 w-5 text-purple-400" />
            </div>
            <p className="text-center text-sm text-purple-200 md:text-left font-semibold">
              AI-Powered 4K Cinematic Video Creation
            </p>
            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2 text-xs text-purple-300">
                <Shield className="h-4 w-4" />
                <span>Secure & Private</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-purple-300">
                <Monitor className="h-4 w-4" />
                <span>4K-Capable Platform</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-green-400">
                <Cloud className="h-4 w-4" />
                <span className="font-semibold">Internet Computer Network</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-blue-400">
                <Globe className="h-4 w-4" />
                <a 
                  href="https://boldman.ai" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="font-semibold hover:text-blue-300 transition-colors"
                >
                  boldman.ai
                </a>
              </div>
            </div>
          </div>

          {/* Features Section */}
          <div className="flex flex-col items-center gap-2 text-center">
            <h3 className="text-sm font-semibold text-white">Platform Features</h3>
            <ul className="space-y-1 text-xs text-purple-300">
              <li>4K Cinematic Video Creation</li>
              <li>Multi-Character Story Builder</li>
              <li>AI Voice-Over Generation</li>
              <li>3D Character Animation</li>
              <li>Multi-Language Support</li>
              <li>Subscription with Charity</li>
              <li>AI Prompt Assistant</li>
              <li>Content Safety Detection</li>
            </ul>
            <div className="mt-2 text-xs text-purple-400">
              <span className="font-semibold">PWA Enabled:</span> Web, Android, iOS, Windows
            </div>
          </div>

          {/* Attribution & Licensing Section */}
          <div className="flex flex-col items-center gap-3 md:items-end">
            <div className="flex flex-col items-center gap-2 md:items-end">
              <div className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-purple-600/20 to-pink-600/20 px-3 py-2 border border-purple-500/30">
                <Award className="h-4 w-4 text-purple-400" />
                <span className="text-xs text-purple-200 font-semibold">Full Commercial Rights</span>
              </div>
              <div className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-green-600/20 to-emerald-600/20 px-3 py-2 border border-green-500/30">
                <Cloud className="h-4 w-4 text-green-400" />
                <span className="text-xs text-green-200 font-semibold">Internet Computer</span>
              </div>
              <div className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-blue-600/20 to-cyan-600/20 px-3 py-2 border border-blue-500/30">
                <Globe className="h-4 w-4 text-blue-400" />
                <a 
                  href="https://boldman.ai" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xs text-blue-200 font-semibold hover:text-blue-100 transition-colors"
                >
                  boldman.ai
                </a>
              </div>
              <p className="flex items-center gap-2 text-sm text-purple-200">
                © 2025. Built with{' '}
                <Heart className="h-4 w-4 fill-pink-500 text-pink-500 animate-pulse" /> using
              </p>
              <a
                href="https://caffeine.ai"
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-2 rounded-lg bg-gradient-to-r from-purple-600/20 to-pink-600/20 px-4 py-2 transition-all hover:from-purple-600/30 hover:to-pink-600/30 hover:shadow-glow"
              >
                <span className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400 group-hover:from-purple-300 group-hover:to-pink-300">
                  caffeine.ai
                </span>
              </a>
            </div>
            <p className="text-xs text-purple-400 text-center md:text-right font-semibold">
              BoldMan - Professional Edition v1.0.0
            </p>
          </div>
        </div>

        {/* Bottom Bar with Official Production Status and Credit Line */}
        <div className="mt-6 border-t border-white/10 pt-4">
          <div className="flex flex-col items-center gap-3 text-center">
            <div className="flex items-center gap-2 mb-2 flex-wrap justify-center">
              <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-3 py-1 rounded-full text-xs font-bold shadow-glow flex items-center gap-1">
                <Cloud className="h-3 w-3" />
                <span>INTERNET COMPUTER DEPLOYMENT</span>
              </div>
              <div className="bg-gradient-to-r from-green-600 to-emerald-600 text-white px-3 py-1 rounded-full text-xs font-bold shadow-glow">
                PUBLIC NETWORK
              </div>
              <div className="bg-gradient-to-r from-blue-600 to-cyan-600 text-white px-3 py-1 rounded-full text-xs font-bold shadow-glow flex items-center gap-1">
                <Globe className="h-3 w-3" />
                <span>boldman.ai</span>
              </div>
            </div>
            
            {/* Professional Credit Line with Shimmer Effect */}
            <p className="text-xs italic animate-shimmer bg-gradient-to-r from-gray-500 via-gray-300 to-gray-500 bg-[length:200%_auto] bg-clip-text text-transparent">
              Creative Support by Caffeine AI
            </p>
            
            <p className="text-xs text-purple-400">
              This is an AI-powered platform. All content is user-generated.
            </p>
            <p className="text-xs text-purple-500">
              <strong>Licensing:</strong> Full ownership and exclusive commercial rights granted to user. 
              All generated content belongs to you.
            </p>
            <p className="text-xs text-purple-600 mt-1">
              BoldMan AI Cinematic Creator - Official production release on the public Internet Computer network at <strong>boldman.ai</strong> ready for public publishing and commercial use
            </p>
            <p className="text-xs text-green-500 mt-2 font-semibold">
              ✓ Internet Computer Network • ✓ Custom Domain (boldman.ai) • ✓ Decentralized & Secure • ✓ Cross-Platform PWA • ✓ Full Commercial Rights
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}

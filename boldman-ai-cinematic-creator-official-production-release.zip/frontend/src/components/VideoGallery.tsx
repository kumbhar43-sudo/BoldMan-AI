import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Play, Download, Share2, Clock, User, Edit } from 'lucide-react';
import { useGetVideosByUser, useGetAllPublicVideos } from '../hooks/useQueries';
import { VideoStatus } from '../backend';
import type { VideoProject } from '../backend';

interface VideoGalleryProps {
  type: 'user' | 'public';
}

export default function VideoGallery({ type }: VideoGalleryProps) {
  const userVideosQuery = useGetVideosByUser();
  const publicVideosQuery = useGetAllPublicVideos();

  const query = type === 'user' ? userVideosQuery : publicVideosQuery;
  const { data: videos, isLoading } = query;

  const getStatusBadge = (status: VideoStatus) => {
    const statusMap: Record<VideoStatus, { label: string; variant: 'default' | 'secondary' | 'outline' | 'destructive' }> = {
      [VideoStatus.draft]: { label: 'Draft', variant: 'secondary' },
      [VideoStatus.rendering]: { label: 'Rendering', variant: 'default' },
      [VideoStatus.completed]: { label: 'Completed', variant: 'outline' },
      [VideoStatus.failed]: { label: 'Failed', variant: 'destructive' },
    };

    const config = statusMap[status];
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const formatDate = (timestamp: bigint) => {
    const date = new Date(Number(timestamp) / 1000000);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  if (isLoading) {
    return (
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
            <CardContent className="p-6">
              <div className="aspect-video bg-white/10 rounded-lg mb-4 animate-pulse" />
              <div className="h-6 bg-white/10 rounded mb-2 animate-pulse" />
              <div className="h-4 bg-white/10 rounded w-2/3 animate-pulse" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (!videos || videos.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="mb-4 flex justify-center">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-white/10">
            <Play className="h-10 w-10 text-purple-300" />
          </div>
        </div>
        <h3 className="text-2xl font-semibold text-white mb-2">
          {type === 'user' ? 'No Videos Yet' : 'No Public Videos'}
        </h3>
        <p className="text-purple-200">
          {type === 'user'
            ? 'Click "Create New Video" to start your first project'
            : 'No public videos available yet'}
        </p>
      </div>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {videos.map((video) => (
        <Card
          key={video.id.toString()}
          className="border-purple-500/30 bg-white/5 backdrop-blur-lg hover:bg-white/10 transition-all group"
        >
          <CardContent className="p-6">
            <div className="aspect-video bg-gradient-to-br from-purple-600 to-pink-600 rounded-lg mb-4 flex items-center justify-center relative overflow-hidden">
              {video.previewFile ? (
                <img 
                  src={video.previewFile.getDirectURL()} 
                  alt={video.title}
                  className="w-full h-full object-cover"
                />
              ) : (
                <>
                  <Play className="h-12 w-12 text-white opacity-80 group-hover:scale-110 transition-transform" />
                  <div className="absolute inset-0 bg-black/20" />
                </>
              )}
            </div>
            
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-lg font-semibold text-white line-clamp-2">
                  {video.title}
                </h3>
                {getStatusBadge(video.status)}
              </div>

              {video.description && (
                <p className="text-sm text-purple-200 line-clamp-2">
                  {video.description}
                </p>
              )}

              <div className="flex items-center gap-4 text-xs text-purple-300">
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  {formatDate(video.createdAt)}
                </div>
                {type === 'public' && (
                  <div className="flex items-center gap-1">
                    <User className="h-3 w-3" />
                    {video.userId.toString().substring(0, 8)}...
                  </div>
                )}
              </div>

              <div className="flex gap-2 pt-2">
                <Button
                  size="sm"
                  className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  <Play className="mr-1 h-3 w-3" />
                  Play
                </Button>
                {type === 'user' && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-white/20 bg-white/10 text-white hover:bg-white/20"
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  className="border-white/20 bg-white/10 text-white hover:bg-white/20"
                >
                  <Download className="h-3 w-3" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-white/20 bg-white/10 text-white hover:bg-white/20"
                >
                  <Share2 className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, MessageSquare, Lightbulb, Loader2, Copy, Check } from 'lucide-react';
import { useCallExternalGeminiAPI } from '../hooks/useQueries';
import { toast } from 'sonner';

interface AiPromptAssistantProps {
  context: string;
  onSuggestionApply: (suggestion: string) => void;
  placeholder?: string;
  mode?: 'script' | 'story' | 'explainer';
}

export default function AiPromptAssistant({
  context,
  onSuggestionApply,
  placeholder = 'Ask AI for help...',
  mode = 'script',
}: AiPromptAssistantProps) {
  const [prompt, setPrompt] = useState('');
  const [chatResponse, setChatResponse] = useState('');
  const [geminiSuggestions, setGeminiSuggestions] = useState<string[]>([]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'chat' | 'suggestions'>('chat');

  const callGemini = useCallExternalGeminiAPI();

  const handleChatGptStyle = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a prompt');
      return;
    }

    try {
      const fullPrompt = `Context: ${context}\n\nUser Request: ${prompt}\n\nProvide a helpful, creative response for ${mode} creation.`;
      const response = await callGemini.mutateAsync(fullPrompt);
      setChatResponse(response);
      toast.success('AI response generated!');
    } catch (error) {
      console.error('Error calling AI:', error);
      toast.error('Failed to generate AI response');
    }
  };

  const handleGeminiSuggestions = async () => {
    if (!context.trim()) {
      toast.error('Please provide some content first');
      return;
    }

    try {
      const fullPrompt = `Analyze this ${mode} content and provide 3-5 specific improvement suggestions:\n\n${context}\n\nProvide suggestions as a numbered list.`;
      const response = await callGemini.mutateAsync(fullPrompt);
      
      // Parse response into suggestions
      const suggestions = response
        .split('\n')
        .filter(line => line.match(/^\d+\./))
        .map(line => line.replace(/^\d+\.\s*/, '').trim());
      
      setGeminiSuggestions(suggestions);
      toast.success('Suggestions generated!');
    } catch (error) {
      console.error('Error calling AI:', error);
      toast.error('Failed to generate suggestions');
    }
  };

  const handleCopySuggestion = (suggestion: string, index: number) => {
    navigator.clipboard.writeText(suggestion);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
    toast.success('Copied to clipboard');
  };

  const handleApplySuggestion = (suggestion: string) => {
    onSuggestionApply(suggestion);
    toast.success('Suggestion applied!');
  };

  return (
    <Card className="border-purple-500/30 bg-white/5 backdrop-blur-lg">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-400" />
          AI Prompt Assistant
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'chat' | 'suggestions')}>
          <TabsList className="grid w-full grid-cols-2 bg-white/10">
            <TabsTrigger value="chat" className="data-[state=active]:bg-purple-600">
              <MessageSquare className="mr-2 h-4 w-4" />
              ChatGPT Style
            </TabsTrigger>
            <TabsTrigger value="suggestions" className="data-[state=active]:bg-purple-600">
              <Lightbulb className="mr-2 h-4 w-4" />
              Gemini Suggestions
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="space-y-4 mt-4">
            <div className="space-y-2">
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder={placeholder}
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50 min-h-24"
              />
              <Button
                onClick={handleChatGptStyle}
                disabled={callGemini.isPending}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                {callGemini.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <MessageSquare className="mr-2 h-4 w-4" />
                    Get AI Response
                  </>
                )}
              </Button>
            </div>

            {chatResponse && (
              <div className="space-y-2">
                <div className="p-4 bg-white/10 border border-white/20 rounded-lg">
                  <p className="text-white text-sm whitespace-pre-wrap">{chatResponse}</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => handleCopySuggestion(chatResponse, -1)}
                    variant="outline"
                    size="sm"
                    className="border-white/20 bg-white/10 text-white hover:bg-white/20"
                  >
                    <Copy className="mr-2 h-3 w-3" />
                    Copy
                  </Button>
                  <Button
                    onClick={() => handleApplySuggestion(chatResponse)}
                    variant="outline"
                    size="sm"
                    className="border-white/20 bg-white/10 text-white hover:bg-white/20"
                  >
                    Apply
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="suggestions" className="space-y-4 mt-4">
            <Button
              onClick={handleGeminiSuggestions}
              disabled={callGemini.isPending || !context.trim()}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
            >
              {callGemini.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Lightbulb className="mr-2 h-4 w-4" />
                  Analyze & Suggest
                </>
              )}
            </Button>

            {geminiSuggestions.length > 0 && (
              <div className="space-y-3">
                {geminiSuggestions.map((suggestion, index) => (
                  <div
                    key={index}
                    className="p-3 bg-white/10 border border-white/20 rounded-lg space-y-2"
                  >
                    <p className="text-white text-sm">{suggestion}</p>
                    <div className="flex gap-2">
                      <Button
                        onClick={() => handleCopySuggestion(suggestion, index)}
                        variant="outline"
                        size="sm"
                        className="border-white/20 bg-white/10 text-white hover:bg-white/20"
                      >
                        {copiedIndex === index ? (
                          <>
                            <Check className="mr-2 h-3 w-3" />
                            Copied
                          </>
                        ) : (
                          <>
                            <Copy className="mr-2 h-3 w-3" />
                            Copy
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={() => handleApplySuggestion(suggestion)}
                        variant="outline"
                        size="sm"
                        className="border-white/20 bg-white/10 text-white hover:bg-white/20"
                      >
                        Apply
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {geminiSuggestions.length === 0 && !callGemini.isPending && (
              <div className="text-center py-8">
                <Lightbulb className="h-12 w-12 text-purple-300 mx-auto mb-3 opacity-50" />
                <p className="text-purple-300 text-sm">
                  Add some content first, then click "Analyze & Suggest" to get AI-powered improvements
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

import { useEffect, useState } from 'react';
import { useInternetIdentity } from './hooks/useInternetIdentity';
import { useGetCallerUserProfile, useIsCallerAdmin } from './hooks/useQueries';
import { Toaster } from '@/components/ui/sonner';
import { ThemeProvider } from 'next-themes';
import Header from './components/Header';
import Footer from './components/Footer';
import ProfileSetupDialog from './components/ProfileSetupDialog';
import Dashboard from './pages/Dashboard';
import OwnerDashboard from './pages/OwnerDashboard';
import LandingPage from './pages/LandingPage';
import PaymentSuccessPage from './pages/PaymentSuccessPage';
import PaymentCancelPage from './pages/PaymentCancelPage';
import SubscriptionDialog from './components/SubscriptionDialog';

export default function App() {
  const { identity, isInitializing } = useInternetIdentity();
  const { data: userProfile, isLoading: profileLoading, isFetched } = useGetCallerUserProfile();
  const { data: isAdmin, isLoading: adminLoading } = useIsCallerAdmin();
  const [showSubscriptionDialog, setShowSubscriptionDialog] = useState(false);

  const isAuthenticated = !!identity;
  const showProfileSetup = isAuthenticated && !profileLoading && isFetched && userProfile === null;

  // Check URL for actions
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const action = params.get('action');
    
    if (action === 'subscribe' && isAuthenticated) {
      setShowSubscriptionDialog(true);
    }
  }, [isAuthenticated]);

  // Check if we're on payment result pages
  const path = window.location.pathname;
  const isPaymentSuccess = path === '/payment-success';
  const isPaymentCancel = path === '/payment-cancel';

  if (isInitializing) {
    return (
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
        <div className="flex h-screen items-center justify-center bg-gradient-to-br from-purple-900 via-indigo-900 to-blue-900">
          <div className="text-center">
            <div className="mb-4 h-16 w-16 animate-spin rounded-full border-4 border-purple-500 border-t-transparent mx-auto"></div>
            <p className="text-white text-lg">Loading...</p>
          </div>
        </div>
      </ThemeProvider>
    );
  }

  // Determine which dashboard to show
  const showOwnerDashboard = isAuthenticated && !adminLoading && isAdmin === true;
  const showUserDashboard = isAuthenticated && !showOwnerDashboard;

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
      <div className="flex min-h-screen flex-col bg-gradient-to-br from-purple-950 via-indigo-950 to-blue-950">
        <Header />
        <main className="flex-1">
          {isPaymentSuccess ? (
            <PaymentSuccessPage />
          ) : isPaymentCancel ? (
            <PaymentCancelPage />
          ) : showOwnerDashboard ? (
            <OwnerDashboard />
          ) : showUserDashboard ? (
            <Dashboard />
          ) : (
            <LandingPage />
          )}
        </main>
        <Footer />
        {showProfileSetup && <ProfileSetupDialog />}
        {showSubscriptionDialog && (
          <SubscriptionDialog
            open={showSubscriptionDialog}
            onClose={() => setShowSubscriptionDialog(false)}
          />
        )}
        <Toaster />
      </div>
    </ThemeProvider>
  );
}
